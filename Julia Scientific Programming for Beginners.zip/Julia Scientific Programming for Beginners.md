# Julia Scientific Programming for Beginners
###  　──Pythonのように書けて、Cのように速い──
![image.png](attachment:image.png)
# 0.はじめに
　PythonやRをはじめとしたプログラミング言語によって分析を行う人が増えてきました。もちろん従来からあるコーディング不要のExcelなども強力な分析ツールではあるのですが、GBクラス以上のデータを扱うには不便だったりするなど、PythonやRを使ったほうが便利な側面もあります。一方、個人的にはその処理能力や速度も「もっと早くなれば良いのにな」と思うところがあり、僕が推したいプログラミング言語はPythonでもなくRでもなく<b>Julia</b>です(ちなみにMATLABやOctaveも好きです)。しかしながらPythonやRをはじめとした様々な言語に関しては巷に入門書があふれていますが、開発されて間もない言語だということもありJuliaに関しては少ないため、とりあえず書いてみることにしました。<br>

Juliaは<br>
- Pythonのように書けてCのように早い<br>
- 数値計算、機械学習、統計、データ解析なども得意<br>
- 数式をきれいに書くことができる (例. 2Xを2*Xではなく、2Xと書ける)<br>

といった、ことから最近流行りの言語になっています。実際、非常に高速なのと可読性の高さから、個人的にはPythonやRより優れていると感じています。<br>
　ちなみに、こちらは理化学研究所生命機能科学研究センターの[佐藤建太さんの資料](https://www.slideshare.net/KentaSato/julia-2015?from_action=save) から拝借した図ですが、いかにJuliaが早いかが一目でわかります。
![image-2.png](attachment:image-2.png)
他にも、JuliaのHPを見に行くと<br>
- Cのように早い<br>
- Rubyのような動的さ<br>
- Lispのような真のマクロ<br>
- Rのような統計処理<br>
- Pythonのような汎用性<br>
- Perlの文字処理のように自然<br>
- Shellのような簡単な連結<br>
- MatLabのような線形代数<br>
- シンプルで、学びやすい<br>
- 上級者でも満足できる<br>

と、非常に"貪欲な"言語であることがわかります。(Julia公式も貪欲さがが売りであると公言しています)<br>
>We want a language that's open source, with a liberal license. We want the speed of C with the dynamism of Ruby. We want a language that's homoiconic, with true macros like Lisp, but with obvious, familiar mathematical notation like Matlab. We want something as usable for general programming as Python, as easy for statistics as R, as natural for string processing as Perl, as powerful for linear algebra as Matlab, as good at gluing programs together as the shell. Something that is dirt simple to learn, yet keeps the most serious hackers happy. We want it interactive and we want it compiled.<br>
Source: https://julialang.org/blog/2012/02/why-we-created-julia/

　なお、「JuliaはPythonの完全上位互換でJuliaさえあればPythonは不要」というわけではなく、Juliaを開発したMITの方々はPythonではできない/苦手な/遅いことをJuliaでやる、という位置づけで使っており、Juliaで仕事をするときにもPythonを呼び出すことはよくあることであることは注意してください。また、JuliaからPythonやRを使うと、直接PythonやRを使った場合よりもさらに一段深い理解が必要になる場合があって、JuliaをやればPythonやRへの理解も深まる場合があるので、PythonやRの勉強も怠らないようにしましょう。<br>
　PythonとJuliaの違いとしては、Pythonは、科学分野の巨大なユーザーコミュニティが既に存在し、優れた科学的・一般的なエコシステムを特徴とする汎用言語です。一方、Juliaは主に技術的・科学的なコンピューティングに特化した言語であり、最先端の手法やアルゴリズムを扱う優れたエコシステムを備えています。どちらも現代的なオープンソースの生産性の高い言語であり，ハイパフォーマンスコンピューティングに必要な様々な機能を備えています。

### 本チュートリアルの想定読者
- Juliaプログラミングに興味がある方<br>
- 新しいプログラミング言語を学びたい方<br>
- Fortran、Pythonなど、既にプログラミング言語を使ったことのある方 (なくても可)<br>
 
### 本チュートリアルの達成目標
- 自分で簡単なJuliaプログラムをゼロから書けるようになる
- コンピュータ言語としてのJuliaの利点と能力を理解する
- Plots、DataFrames、Statsなどの様々なJuliaパッケージの使用できるようになる

### 本チュートリアルで扱わない・達成できないこと
- 熟練したプログラマーになるためには、<b>本チュートリアル上の作業だけでは不十分</b>です。これは、長くて美しく、新しい関係の始まりの"最初のデート"のようなものだとお考え下さい。そして、今回のチュートリアルをきっかけとして、これから先Juliaについて様々な良い点や悪い点について気づき、発見していって下さい。<br>
- 本チュートリアルでは実際のデータを用いた<b>ケーススタディ的な分析は行いません</b>。あくまで基本文法や扱い方についての解説のみに終始します。<br>
- 本チュートリアルではプログラミング言語としてのJuliaのみに焦点を当て、<b>統計学的な内容の解説は行いません</b>。

### 目次
1. 環境設定
2. 基本的な文法
3. データ構造
4. 配列
5. 制御構造
6. 関数
7. モジュール
8. ファイル入出力
9. 可視化
10. データフレーム
11. 科学計算

# 1.環境構築
　以下のURLからJuliaをインストールし、環境構築については下記のqiitaの手順通りに行えば何とかなります。
Juliaをやってみようとする人は既にpythonとかをいじったことがあると思っているのでAnacondaやJupyterは既に入っている前提ですが、入っていない人は適当にググって入れてください。なんならこの記事もJuypter Notebookで書いています。一応参考までに、windowsとmacそれぞれにおけるAnacondaのインストール方法も簡単にですが記述しておきます。

インストール<br>
https://julialang.org/downloads/

環境構築 (for window)<br>
https://qiita.com/msekino/items/dbfe11ad05f20fd3efd3

環境構築 (for Mac)<br>
https://qiita.com/SatoshiTerasaki/items/41df235328badcf382eb

<参考> Anacondaのインストール方法 for Windows
1. Download <b>Anaconda</b> (includes Python and Jupyter) from the Anaconda website (https://www.anaconda.com/products/individual#download-section).
2. Save the package to a <b>C:\Temp</b> and double-click the file to run the installer.
3. Click <b>Next</b>.
4. Read the licensing terms and click <b>I Agree</b>.
5. Select install for <b>Just Me</b> and click <b>Next</b>.
6. Select a destination folder to install Anaconda and click the <b>Next</b> button.
7. Choose <b>Register Anaconda as my default Python 3.7</b> and click <b>Install</b>.
8. After the package has finished installing, click <b>Next</b> and then <b>Finish</b>.
9. Go to <b>Start</b> and open <b>Anaconda Prompt</b> and type <b>python --version</b> and press <b>Enter</b> to check if Python was installed properly. You should see here Python 3.7. If <b>Python</b> is <b>not installed</b>, you can download it from the Python site (https://www.python.org/downloads/).
10. To open Jupyter Notebook, type <b>jupyter notebook</b> in the Anaconda Prompt and press <b>Enter</b>.

<参考> Anacondaのインストール方法 for Mac
1. Download Anaconda (includes Python and Jupyter) from the Anaconda website (https://www.anaconda.com/products/individual#download-section).
2. Click the <b>Anaconda.pkg</b>
3. On the Installation screen, follow the Installation by clicking on <b>Continue</b>.
4. Once the application is installed.
5. Look for <b>Anaconda Navigator</b> on the search.

# 2. 基本的な文法
## 2-1. 出力、定数と変数
### 出力
出力をするためにはお馴染みの<b>printもしくはprintln</b>をJuliaでも使います<br>
print("XXXX")<br>
println("XXXX")<br>
<b>lnは改行を表す</b>ので、何行も出力する場合にはlnを付けたほうがよいですね。


```julia
print("Hello World!")
```

    Hello World!


```julia
println("Hello World!")
```

    Hello World!
    

### 変数
変数を定義する場合は<br>
<b>変数名 = 変数に代入したい値</b><br>
と書くと変数を設定できます。これは整数だけでなく小数なども変数として入力できます。


```julia
#変数xを定義する
x = 10
```




    10




```julia
#変数yを定義する
y = 1.0
```




    1.0



変数の型を確認したい場合は<b>typeof</b>を使います


```julia
x = 10
typeof(x)
```




    Int64




```julia
y = 1.0
typeof(y)
```




    Float64



演算も、他の言語と同様にできます


```julia
x = 10
y = 1.0
#x+yを計算する
z = x + y
```




    11.0




```julia
typeof(z)
```




    Float64



普通は式を実行すると結果が表示されますが、毎回結果が返ってくると煩わしい場合には数式の最後に;(セミコロン)を打つと、実行しても結果は表示されなくなります。


```julia
x = 10
y = 1.0
z = x + y;
```

### 定数
x=1<br>
の後に<br>
x=10<br>
とコードを書けば、xの値は1から10に上書きされますが、上書きされたくない定数を定義したい場合は、最初に<b>const</b>を付けます


```julia
#定数を定義する
const teisuu = 3.0
```




    3.0




```julia
#定数を上書きしようとする場合にはwarningが出る
teisuu = 10
```


    invalid redefinition of constant teisuu

    

    Stacktrace:

     [1] top-level scope

       @ In[11]:2

     [2] eval

       @ .\boot.jl:360 [inlined]

     [3] include_string(mapexpr::typeof(REPL.softscope), mod::Module, code::String, filename::String)

       @ Base .\loading.jl:1094


上記のように、constを付けた後に定義した定数を上書きしようとすると警告が発生します。<br>
また、constを付けて定数として定義すると参照のスピードが上がるので、大規模な計算を行う際には速度面で有利になります。

## 2-2. 文字列

文字列はダブルクォーテーション("")にて定義します。他の言語とは異なり、<b>シングルクォーテーション('')では定義できない</b>ことに注意してください。


```julia
#文字列を定義する
c = "Julia"
```




    "Julia"




```julia
#シングルクォーテーションでは定義できない
cc = 'Julia'
```


    syntax: character literal contains multiple characters

    

    Stacktrace:

     [1] top-level scope

       @ In[13]:2

     [2] eval

       @ .\boot.jl:360 [inlined]

     [3] include_string(mapexpr::typeof(REPL.softscope), mod::Module, code::String, filename::String)

       @ Base .\loading.jl:1094


<b>文字列の連結は*</b>を用います (他言語とは違い、<b>+ではない！</b>)


```julia
h = "Hello "
c = "Julia"
#文字列hとcを連結させる
print(h * c)
```

    Hello Julia

文字の取り出しを行う場合には<br>
<b>変数[インデックス]</b><br>
<b>変数[取り出し開始文字のインデックス:取り出し終了文字のインデックス]</b><br>
と記述します。<br>
Juliaの場合<b>インデックスは1から始まる</b>ので、1文字目を取り出したい場合は0ではなく1を指定してください。


```julia
c = "Julia"
#c、つまり、Juliaの一文字目であるJを取り出す
c[1]
```




    'J': ASCII/Unicode U+004A (category Lu: Letter, uppercase)




```julia
c = "Julia"
#"Julia"の2文字目から4文字目までを取り出す
c[2:4]
```




    "uli"



文字列が何文字で構成されているかを調べるには<b>length関数</b>を用います (スペースも1文字として計算されます)


```julia
c = "Julia"
#"Julia"が何文字かを調べる
length(c)
```




    5




```julia
h = "Hello "
c = "Julia"
length(h*c)
```




    11



<b>split関数</b>で分割することができます<br>
<b>split(分割したい文字列, "何をキーとして分割するか")</b><br>
と記述してください。


```julia
h = "Hello "
c = "Julia"
#半角スペースをキーとして、h * cを分割する
split(h * c," ")
```




    2-element Vector{SubString{String}}:
     "Hello"
     "Julia"




```julia
hh = "Hello,julia"
split(h * c,",")
```




    1-element Vector{SubString{String}}:
     "Hello Julia"



小文字と大文字の変換は、以下のよう記述します。<br>
<b>lowercase(小文字にしたい文字列)<br>
uppercase(大文字にしたい文字列)</b><br>
これで大文字から小文字、小文字から大文字に変換ができます。


```julia
name = "Julia"
#nameを全て小文字化する
lowercase(name)
```




    "julia"




```julia
name = "Julia"
#nameを全て大文字化する
uppercase(name)
```




    "JULIA"



## 2-3 型変換

### 文字列から数値に変換する
<b>parse</b>を用いて<br>
<b>parse(変換したい型, 変換したい値)</b><br>
と記述します


```julia
number = "12345"
typeof(number)
```




    String




```julia
number = "12345"
#numberを文字列からInt型に変換する
number1 = parse(Int, number)
```




    12345




```julia
typeof(number1)
```




    Int64




```julia
number = "12345"
#numberを文字列からFloar型に変換する
number2 = parse(Float64, number)
```




    12345.0




```julia
typeof(number2)
```




    Float64



### 数値から文字列への変換する
数値から文字列に変換したい場合は、<b>string関数</b>を使用し、<br>
<b>string(文字列にしたい値)</b><br>
と記述します。


```julia
number = 12334
typeof(number)
```




    Int64




```julia
str = string(number)
```




    "12334"




```julia
typeof(str)
```




    String



また、<b>round関数</b>を用いることで数値を丸めることができ、<br>
<b>round(型, 丸めたい数値)</b><br>
と記述します。


```julia
pi = 3.1415
round(pi)
```




    3.0




```julia
round(Int, pi)
```




    3



## 2-4. 演算

### 基本的な演算
基本的な演算はほかの言語と同じです。<br>
　足し算: a + b<br>
　引き算: a - b<br>
　掛け算: a * b<br>
　割り算: a / b<br>
　余り: a % b<br>
　べき乗: a ^ b


```julia
x = 3
y = 5
x+y
```




    8




```julia
x = 3
y = 5
x-y
```




    -2




```julia
x = 3
y = 5
x * y
```




    15




```julia
x = 3
y = 5
x/y
```




    0.6




```julia
x = 3
y = 5
#ｙをxで割った余りを計算
y % x
```




    2




```julia
x = 3
y = 5
#xのy乗を計算
x ^ y
```




    243



### 論理式
論理式についても、他のプログラミング言語と同様に記述できます。


```julia
x > y
```




    false




```julia
x < y
```




    true




```julia
x = 1
y = 0
x != y
```




    true



### 文字についての演算
既にある変数を上書きする際には、ほかのプログラミング言語と同様<br>
x = x+1<br>
や<br>
x += 1<br>
などといった記述ができます。


```julia
x = 3
#xに1を足したものをxに代入する
x = x+1
```




    4




```julia
x = 3
#xに1を足したものをxに代入する
x += 1
```




    4




```julia
x = 3
#xに1を引いたものをxに代入する
x -= 1
```




    2



1行に複数の作業を行いたい場合には、;(セミコロン)を付けます


```julia
x = 3 ; y = 5
```




    5




```julia
print(x)
```

    3


```julia
print(y)
```

    5

## 2-5. NaN / Inf
### NaN
NaNとはNot-A-Numberの略で非数を表し、Infはinfinitiの略で無限大を表します。
他のプログラミング言語だとNaNの扱いは難しいこともありますが、JuliaだとNaNの扱いも簡単です。<br>
単純に<br>
<b>NaNを代入したい変数 = NaN</b><br>
と入力するだけでNaNを扱えます


```julia
x = NaN
```




    NaN



NaNを判定する場合には<b>isnan関数</b>を用います。


```julia
x = NaN
isnan(x)
```




    true




```julia
y = 1
isnan(y)
```




    false



### Inf
Infも<br>
Infを代入したい変数 = Inf<br>
と入力することで扱えます。


```julia
z = Inf
```




    Inf



Infか否かを判定するには<b>isinf関数</b>を用います。


```julia
z = Inf
isinf(z)
```




    true




```julia
y = 1
isinf(y)
```




    false



# 3. データ構造
## 3-1. タプル

タプルは丸かっこ()で定義をし、カンマ区切りで入力します。


```julia
a = (0,1,2,3,4,5)
```




    (0, 1, 2, 3, 4, 5)




```julia
typeof(a)
```




    NTuple{6, Int64}



実は丸かっこ()なしでもタプルを定義することができます。


```julia
b = 2,3,4,5
```




    (2, 3, 4, 5)




```julia
typeof(b)
```




    NTuple{4, Int64}



タプルの中の要素の取り出しは他のプログラミング言語と同様にインデックスを指定して行いますが、<b>Juliaの場合はインデックスが1から始まる</b>ことに気を付けてください。<br>
また、タプルはスライスも他の言語と同様に実行することができます。


```julia
a = (0,1,2,3,4,5)
#タプルaの一番最初の要素を取り出す。
a[1]
```




    0




```julia
a = (0,1,2,3,4,5)
#タプルの1番目から3番目までの要素を取り出す。
a[1:3]
```




    (0, 1, 2)



<b>(重要) タプルはimmutableなので、一度作成したらその中の値を変更することはできません。</b>


```julia
a = (0,1,2,3,4,5)
#タプルaの1番目の要素を10に変更しようとするとエラーが返ってくる
a[1] = 10
```


    MethodError: no method matching setindex!(::NTuple{6, Int64}, ::Int64, ::Int64)

    

    Stacktrace:

     [1] top-level scope

       @ In[60]:3

     [2] eval

       @ .\boot.jl:360 [inlined]

     [3] include_string(mapexpr::typeof(REPL.softscope), mod::Module, code::String, filename::String)

       @ Base .\loading.jl:1094


タプルにはタプル内の各要素に名前を付けることもできます。<br>
また、要素を取り出す際には以下のように名前を指定して取り出すこともできます。<br>
<b>タプル名.要素名</b>


```julia
t = (x = 1, y = 2, z = 3)
```




    (x = 1, y = 2, z = 3)




```julia
#名前が付けられたタプルの型はNamedTupleとなる。
typeof(t)
```




    NamedTuple{(:x, :y, :z), Tuple{Int64, Int64, Int64}}




```julia
t = (x = 1, y = 2, z = 3)
#タプルt内の、xの要素を取得
t.x
```




    1



タプル内容その名前(キー)のみを取り出したい場合には<b>keys関数</b>を用います。<br>
また、値のみを取り出したい場合には<b>values関数</b>を用います


```julia
t = (x = 1, y = 2, z = 3)
keys(t)
```




    (:x, :y, :z)




```julia
t = (x = 1, y = 2, z = 3)
values(t)
```




    (1, 2, 3)



タプルの要素数を参照する場合には<b>length</b>関数を用います。


```julia
t = (x = 1, y = 2, z = 3)
length(t)
```




    3



タプルにすべて要素が入っているのかを確かめる場合には<b>isempty関数</b>を用います。


```julia
t = (x = 1, y = 2, z = 3)
isempty(t)
```




    false



## 3-2. リスト

リストはタプルと似たような形をしていますが、タプルとは違って一度定義した中身を変更することができます。<br>
リストはブラケット[]を用いて定義します。


```julia
l = [1, 2, 3]
```




    3-element Vector{Int64}:
     1
     2
     3



また、空のリストを作成することも可能である。


```julia
l = []
```




    Any[]



タプルと同様、要素が入っているか否かを確かめるには<b>isempty関数</b>を用います


```julia
l = []
isempty(l)
```




    true



要素の追加には<b>push</b>を用い、<br>
<b>push!(追加したいリスト, 追加したい要素)</b><br>
と記述すると、<b>要素を末尾に追加</b>することができます。


```julia
l = []
push!(l, 1)
```




    1-element Vector{Any}:
     1




```julia
push!(l, 10)
```




    2-element Vector{Any}:
      1
     10



要素をリストの先頭に加えたい場合は<b>pushfirst</b>を用い、<br>
<b>pushfirst!(追加したいリスト, 追加したい要素)</b><br>
と記述します。


```julia
pushfirst!(l, 20)
```




    3-element Vector{Any}:
     20
      1
     10



### リストの結合
リストの結合には<b>append関数</b>を用い<br>
<b>append!(元のリスト, 元のリスト追加したいリスト)</b><br>
と記述することで行うことができます。


```julia
s = [30, 40, 50]
append!(l, s)
```




    6-element Vector{Any}:
     20
      1
     10
     30
     40
     50



リストの追加を行った際、追加元のリストには元のリストに新しく積要素が追加されたリストとなりますが、追加したリストの要素は変化しません。


```julia
l
```




    6-element Vector{Any}:
     20
      1
     10
     30
     40
     50




```julia
s
```




    3-element Vector{Int64}:
     30
     40
     50



### リストの末尾の参照
リストの末尾の要素を参照する場合には<b>pop関数</b>を用いて<br>
<b>pop!(末尾を参照したいリスト)</b><br>
と記述します。


```julia
pop!(l)
#リストlの末尾の要素のみを取得
```




    50



### 好きな場所に要素を追加
リストの先頭でも末尾でもなく、任意の場所に要素を追加したい場合は<b>insert関数</b>を用いて<br>
<b>insert!(リスト名, 追加したい場所, 追加したい要素)</b><br>
と記述します。


```julia
insert!(l ,3, 1000)
#リストlの3番目に1,0000を追加
```




    6-element Vector{Any}:
       20
        1
     1000
       10
       30
       40



### 要素の削除
要素をリストから削除する場合は<b>deleteat関数</b>を用いて<br>
<b>deleteat!(リスト名, 削除したい要素の場所)</b><br>
と記述します。


```julia
deleteat!(l, 3)
#要素番号が3の1,000をリストlから削除
```




    5-element Vector{Any}:
     20
      1
     10
     30
     40



### スライス
タプルと同様に、リストでもスライスを行うことができます。


```julia
l[2:4]
#リストlの2番目から4番目までの要素を取得
```




    3-element Vector{Any}:
      1
     10
     30



### リストの最大・最小
最大値の取得には<b>maximum関数</b>、最小値の取得には<b>minimum関数</b>を用い、<br>
<b>maximum(リスト名)<br>
minimum(リスト名)</b><br>
と記述します。


```julia
maximum(l)
```




    40




```julia
minimum(l)
```




    1



## 3-3. 辞書型

辞書（dictionary）型とは、keyとvalueの組み合わせが含まれているデータのことです。<br>
辞書型の定義は、dictを用いて、<br>
<b>Dict("keyの名前" => keyに対応するvalue)</b><br>
と入力します。<br>
また、辞書型のデータセットは順序を持たず、リストと同様定義後に内容の上書きが可能です。


```julia
#辞書dを定義する。
d = Dict("A" => 1, "B" => 2, "C" => 3)
```




    Dict{String, Int64} with 3 entries:
      "B" => 2
      "A" => 1
      "C" => 3




```julia
typeof(d)
```




    Dict{String, Int64}



辞書型のvalueは数値だけでなく、文字列でも可能です。


```julia
d = Dict("A" => "Apple", "B" => "Banana", "C" => "Cherry")
```




    Dict{String, String} with 3 entries:
      "B" => "Banana"
      "A" => "Apple"
      "C" => "Cherry"



### keyからvalueの取得 (その1)
辞書内のvalueを取得する場合は<br>
<b>辞書名["key名"]</b><br>
と記述することで、対応するkeyのvalueを取得できます。


```julia
d = Dict("A" => "Apple", "B" => "Banana", "C" => "Cherry")
#辞書d内のkeyが"A"のvalueを取得
d["A"]
```




    "Apple"



### 辞書の要素の追加
辞書に新しい要素を追加する場合は<br>
<b>辞書名["新しいkey"] = "新しいvalue"</b><br>
と記述します。


```julia
d = Dict("A" => "Apple", "B" => "Banana", "C" => "Cherry")
#辞書dに新たなkey"D"を追加
d["D"] = "Durian"
d
```




    Dict{String, String} with 4 entries:
      "B" => "Banana"
      "A" => "Apple"
      "C" => "Cherry"
      "D" => "Durian"



### 辞書から要素の削除
要素の削除には<b>pop</b>もしくは<b>delete</b>を使用し、<br>
<b>pop!(辞書名, "削除したいkey名")</b>もしくは<br>
<b>delete!(辞書名, "削除したいkey名")</b><br>
と記述することで該当のkeyとvalueを辞書から消すことができます。


```julia
#辞書から"C"を削除する
pop!(d, "C")
```




    "Cherry"




```julia
d
```




    Dict{String, String} with 3 entries:
      "B" => "Banana"
      "A" => "Apple"
      "D" => "Durian"




```julia
#辞書から"A"を削除する
delete!(d, "A")
```




    Dict{String, String} with 2 entries:
      "B" => "Banana"
      "D" => "Durian"



### keyの有無を確認
辞書内にあるkeyがあるか否かを確認する際には、<b>haskey</b>を用いて、<br>
<b>haskey(辞書名, "存在を確認したいkey名")</b><br>
と記述します。


```julia
d = Dict("A" => "Apple", "B" => "Banana", "C" => "Cherry")
#dの中に"B"というkeyが存在するか否かを確認
haskey(d, "B")
```




    true




```julia
d = Dict("A" => "Apple", "B" => "Banana", "C" => "Cherry")
#dの中に"E"というkeyが存在するか否かを確認
haskey(d, "E")
```




    false



### keyからvalueを取得(その2)
辞書内のkeyに対応するvalueを取得する場合は<b>get関数</b>を用いて<br>
<b>get(辞書名, "valueを取得したいkey名", "keyが存在しなかったときに返す値")</b><br>
と記述します。


```julia
d = Dict("A" => "Apple", "B" => "Banana", "C" => "Cherry")
#d内に"A"が存在すれば、そのvalueを返し、なければ"NA"を返す
get(d, "A", "NA")
```




    "Apple"




```julia
d = Dict("A" => "Apple", "B" => "Banana", "C" => "Cherry")
#d内に"E"が存在すれば、そのvalueを返し、なければ"NA"を返す
get(d, "E", "NA")
```




    "NA"



### 辞書の統合
複数の辞書を1つに統合したい場合は<b>merge</b>を使用して、<br>
<b>merge(統合したい辞書1の名前, 統合したい辞書2の名前)</b><br>
と記述します。


```julia
fruit = Dict(11 => "Apple", 12 => "Banana", 13=> "Cherry")
vegitable = Dict(20 => "Avocado", 21 => "Broccoli", 22 => "Carrot")
#辞書fruitoと辞書vegitableを統合
fresh_food = merge(fruit, vegitable)
```




    Dict{Int64, String} with 6 entries:
      22 => "Carrot"
      13 => "Cherry"
      20 => "Avocado"
      11 => "Apple"
      21 => "Broccoli"
      12 => "Banana"



# 4. 配列
## 4-1. 配列の定義

### 一次元配列の定義
配列はブラケット[]を用いて定義します。<br>
<b>一次元配列は列ベクトル</b>となることに注意してください。


```julia
#要素が1つの配列を作成する
[1]
```




    1-element Vector{Int64}:
     1




```julia
#複数の要素を持った配列を定義する
[1, 2, 3]
```




    3-element Vector{Int64}:
     1
     2
     3



### 型を指定して配列を定義する
型を指定して配列を定義する場合は、配列の前に以下のように、型名を記述します<br>
<b>型名[配列]</b>


```julia
#floatでの配列を作成する
Float64[4, 5, 6]
```




    3-element Vector{Float64}:
     4.0
     5.0
     6.0



### 二次元配列の定義
一次元配列と同様にブラケットを使用[]しますが、要素間はカンマではなく<b>スペースで区切る</b>ことに注意してください。(カンマを使用するとエラーを起こします。)<br>
<b>[要素 要素: 要素 要素]</b>


```julia
#二次元配列を定義する
[1 2; 3 4]
```




    2×2 Matrix{Int64}:
     1  2
     3  4




```julia
#スペースではなくカンマで区切ると構文エラーが発生する
[1,2 ; 3,4]
```


    syntax: unexpected semicolon in array expression around In[100]:2

    

    Stacktrace:

     [1] top-level scope

       @ In[100]:2

     [2] eval

       @ .\boot.jl:360 [inlined]

     [3] include_string(mapexpr::typeof(REPL.softscope), mod::Module, code::String, filename::String)

       @ Base .\loading.jl:1094


セミコロンの代わりに改行でも二次元配列を記述することができます。<br>


```julia
#二次元配列を定義する
[1 2
    3 4]
```




    2×2 Matrix{Int64}:
     1  2
     3  4



### 配列の要素の取得
配列から要素を取得する場合には<br>
<b>配列の名前[取り出したい配列の行数, 取り出したい配列の列数]</b><br>
と記述します。この際、行数・列数は0からではなく<b>1から始まる</b>ことに注意してください。


```julia
A = [1 2 3;
    4 5 6;
    7 8 9]
#配列Aの2行1列目の要素を取得する
A[2,1]
```




    4



## 4-2. 配列の初期化

### 初期化されていない配列
まず、初期化された配列を作成する前に、初期化がなされていない配列を作ってみます。初期化されていない配列は<b>Array</b>を用いて<br>
<b>Array{配列の型}(undef, 配列の行数, 配列の列数)</b><br>
と記述して作成します。


```julia
#値が初期化されていない3×4の大きさの配列を用意する
#型は中括弧{}で指定する。今回は単精度(Float32)
Array{Float32}(undef, 3, 4)
```




    3×4 Matrix{Float32}:
     4.0f-45  0.0      7.0f-45  0.0
     0.0      7.0f-45  0.0      7.0f-45
     4.0f-45  0.0      7.0f-45  0.0



### 0 or 1で初期化された配列
0で初期化された配列を作成するには<b>zeros</b>を用いて<br>
<b>zeros(配列の型, 配列の行数, 配列の列数)</b><br>
と記述します。<br>
同様に、1で初期化された配列を作成する場合は、zerosの代わりに<b>ones</b>を用い、<br>
<b>ones(配列の型, 配列の行数, 配列の列数)</b><br>
と記述します。


```julia
#0で初期化された2行3列の配列を作成する
zeros(Float32, 2, 3)
```




    2×3 Matrix{Float32}:
     0.0  0.0  0.0
     0.0  0.0  0.0




```julia
#1で初期化された2行3列の配列を作成する
ones(Float32, 2, 3)
```




    2×3 Matrix{Float32}:
     1.0  1.0  1.0
     1.0  1.0  1.0



### 正規分布に従う乱数で初期化された配列
乱数で配列を初期化する場合は、<b>randn</b>を用いて、<br>
<b>randn(配列の型, 配列の行数, 配列の列数)</b><br>
と記述します。


```julia
#3×3の正規分布に従う配列を作成
randn(Float32, 3, 3)
```




    3×3 Matrix{Float32}:
     -0.854558   1.13698   0.669041
     -1.00185   -1.38462   0.00434573
      1.04788    0.217745  1.19952



### 自分の好きな値で初期化された配列
好きな値で配列を初期化したい場合は、<b>fill</b>を用いて、<br>
<b>fill(好きな値, 配列の行数, 配列の列数)</b><br>
と記述します。


```julia
#要素が100で3×3の配列を初期化
fill(100, 3, 3)
```




    3×3 Matrix{Int64}:
     100  100  100
     100  100  100
     100  100  100



### 配列のサイズ変更
配列のサイズを変える場合には<b>reshape関数</b>を用いて、<br>
<b>reshape（サイズを変えたい配列名, 新しい行数, 新しい列数）</b><br>
と記述します。
この際、<b>列を優先</b>して配列のサイズが変更されます。


```julia
#3×4の配列を作成
A = [1 2 3 4;
    5 6 7 8;
    9 10 11 12]
```




    3×4 Matrix{Int64}:
     1   2   3   4
     5   6   7   8
     9  10  11  12




```julia
#配列Aを4×3に変更する
#配列の要素は列を優先されるので、左上から順に1,5,9,2,6,10,…と埋まっていく
reshape(A, 4, 3)
```




    4×3 Matrix{Int64}:
     1   6  11
     5  10   4
     9   3   8
     2   7  12



## 4-3. CopyとDeepcopy
配列を代入する際に、参照渡しで代入すると、<b>代入先を書き換えると代入元も同時に書き換わってしまいます</b>。


```julia
#正規分布に従う3×3の配列を作成
A = randn(3, 3)
#配列AをBに参照渡しで代入する(この時点で配列AとBの中身は同一になる)
B = A
```




    3×3 Matrix{Float64}:
      0.36452  -0.63736  0.532086
     -1.02579   1.21165  0.296205
      2.26665  -1.79073  0.705331




```julia
#配列Bの1行1列の要素を1に変更
B[1, 1] = 1
```




    1




```julia
B
```




    3×3 Matrix{Float64}:
      1.0      -0.63736  0.532086
     -1.02579   1.21165  0.296205
      2.26665  -1.79073  0.705331




```julia
#配列Bの1行1列を1に変更しただけだが、配列Aの1行1列の要素も1になる
A
```




    3×3 Matrix{Float64}:
      1.0      -0.63736  0.532086
     -1.02579   1.21165  0.296205
      2.26665  -1.79073  0.705331



### copy
参照先の内容を変更しても参照元の内容を変更させないためには、<b>コピー</b>によって代入を行う必要があります。コピーは<b>copy</b>を用いて、<br>
<b>copy(参照元の配列名)</b><br>
と記述します。


```julia
#正規分布に従う3×3の配列を作成
A = randn(3, 3)
#配列AをBに参照渡しで代入する(この時点で配列AとBの中身は同一になる)
B = copy(A)
```




    3×3 Matrix{Float64}:
      0.875341   0.670394  1.14775
     -0.282056   0.739491  2.26485
     -0.917117  -0.217004  1.12111




```julia
#Bの1行1列目に1を代入
B[1, 1] = 1
B
```




    3×3 Matrix{Float64}:
      1.0        0.670394  1.14775
     -0.282056   0.739491  2.26485
     -0.917117  -0.217004  1.12111




```julia
#copyを行うと、参照元である配列Aの値は変わらない
A
```




    3×3 Matrix{Float64}:
      0.875341   0.670394  1.14775
     -0.282056   0.739491  2.26485
     -0.917117  -0.217004  1.12111



### deepcopy
配列の中に配列が入っているような再帰的なパターンをコピーしたい場合には<b>deepcopy</b>を用いて、<br>
<b>deepcopy(参照元の配列名)</b><br>
と記述します。<br>
<b>単純なコピーでは配列の中の配列まではコピーしきれない</b>ことに注意してください。


```julia
#1行1列の配列を作成
hoge = [1]
#配列の中身に配列を入れる
A = [hoge, hoge, hoge]
```




    3-element Vector{Vector{Int64}}:
     [1]
     [1]
     [1]




```julia
#Aをコピーする
B = copy(A)
#配列Bの1つ目の要素の1つ目の要素を2に変換する
B[1][1] = 2
B
```




    3-element Vector{Vector{Int64}}:
     [2]
     [2]
     [2]




```julia
#ただコピーをしただけだと元のhogeが2になってしまう。
hoge
```




    1-element Vector{Int64}:
     2




```julia
#hogeが2になってしまったので、配列Aも全て2になってします。
A
```




    3-element Vector{Vector{Int64}}:
     [2]
     [2]
     [2]




```julia
#1行1列の配列を作成し、配列の中身に配列を入れる
hoge = [3]
A = [hoge, hoge, hoge]
```




    3-element Vector{Vector{Int64}}:
     [3]
     [3]
     [3]




```julia
#deepcopyを使用
B = deepcopy(A)
#配列Bの1つ目の要素の1つ目の要素を0に変換する
B[1][1] = 0
B
```




    3-element Vector{Vector{Int64}}:
     [0]
     [0]
     [0]




```julia
#deepcopyを行った場合は、hogeの値は変更しない
hoge
```




    1-element Vector{Int64}:
     3




```julia
#同様に、配列Aの中身も変更しない
A
```




    3-element Vector{Vector{Int64}}:
     [3]
     [3]
     [3]



## 4-4. 配列の演算

### 配列のサイズがそろっている場合の演算
演算する際には基本的には配列のサイズが同じである必要があります。<br>
また、足し算や引き算はそれぞれの要素ごとに計算しますが、掛け算は配列を行列とみなしての計算となることに注意してください。


```julia
#すべて1の要素を持つ3×3の配列を定義する
A = ones(Float32, 3, 3)
#すべて2の要素を持つ3×3の配列を定義する
B = fill(2.0, 3, 3)
#A+Bを計算
A+B
```




    3×3 Matrix{Float64}:
     3.0  3.0  3.0
     3.0  3.0  3.0
     3.0  3.0  3.0




```julia
A = ones(Float32, 3, 3)
B = fill(2.0, 3, 3)
#A-Bを計算
A-B
```




    3×3 Matrix{Float64}:
     -1.0  -1.0  -1.0
     -1.0  -1.0  -1.0
     -1.0  -1.0  -1.0




```julia
A = ones(Float32, 3, 3)
B = fill(2.0, 3, 3)
#A*Bを計算(席は行列としての演算になる)
A*B
```




    3×3 Matrix{Float64}:
     6.0  6.0  6.0
     6.0  6.0  6.0
     6.0  6.0  6.0



配列の各要素をスカラー倍したい場合は、<br>
<b>スカラー倍したい数値の入った変数名 * 配列名</b><br>
と記述します。


```julia
c = 10
A = ones(Float32, 3, 3)
c * A
```




    3×3 Matrix{Float32}:
     10.0  10.0  10.0
     10.0  10.0  10.0
     10.0  10.0  10.0



### 配列のサイズがそろっていない場合の演算
一般的には配列のサイズがそろっていない配列同士の演算はできませんが、<b>.+</b>など、計算記号の前に<b>.を付けて(ドット演算子)</b>を用いることで、足す配列のサイズを拡張して無理やり計算を行うことができます。


```julia
#各要素が1の3×3の配列を定義する
A = ones(Float32, 3, 3)
#値が2の3次元ベクトルを定義する
B = fill(2,3)
#配列のサイズが違うので足し算をしてもエラーが出る
A + B
```


    DimensionMismatch("dimensions must match: a has dims (Base.OneTo(3), Base.OneTo(3)), must have singleton at dim 2")

    

    Stacktrace:

     [1] promote_shape

       @ .\indices.jl:183 [inlined]

     [2] promote_shape(a::Matrix{Float32}, b::Vector{Int64})

       @ Base .\indices.jl:169

     [3] +(A::Matrix{Float32}, Bs::Vector{Int64})

       @ Base .\arraymath.jl:45

     [4] top-level scope

       @ In[129]:6

     [5] eval

       @ .\boot.jl:360 [inlined]

     [6] include_string(mapexpr::typeof(REPL.softscope), mod::Module, code::String, filename::String)

       @ Base .\loading.jl:1094



```julia
#無理やり演算を実行する場合には".+"を用いる(Bを3×3拡張する)
A .+ B
```




    3×3 Matrix{Float32}:
     3.0  3.0  3.0
     3.0  3.0  3.0
     3.0  3.0  3.0




```julia
A = ones(Float32, 3, 3)
B = fill(2,3)
#Bを3×3拡張して引き算
A .- B
```




    3×3 Matrix{Float32}:
     -1.0  -1.0  -1.0
     -1.0  -1.0  -1.0
     -1.0  -1.0  -1.0




```julia
A = ones(Float32, 3, 3)
c = 10
#ドット演算子はスカラーにも適用できる
A .+ c
```




    3×3 Matrix{Float32}:
     11.0  11.0  11.0
     11.0  11.0  11.0
     11.0  11.0  11.0




```julia
A = ones(Float32, 3, 3)
c = 10
A ./ c
```




    3×3 Matrix{Float32}:
     0.1  0.1  0.1
     0.1  0.1  0.1
     0.1  0.1  0.1



## 4-5. 配列に使う関数

### map関数 (配列内の要素の操作)
<b>map関数</b>を用いて、配列内の要素を一気に操作することができます。<br>
<b>map(x -> 操作名, 適用したい配列名)</b><br>
と記述します。


```julia
#配列Aを一様分布に従う値で初期化
A = rand(3, 3)
```




    3×3 Matrix{Float64}:
     0.205121   0.85181    0.755327
     0.894761   0.993994   0.328313
     0.0461261  0.0152559  0.252927




```julia
#map関数で配列Aの値をすべて10倍する（ドット演算子を使ってスカラー倍することでも同様の操作が可能）
map(x -> x*10, A)
```




    3×3 Matrix{Float64}:
     2.05121   8.5181    7.55327
     8.94761   9.93994   3.28313
     0.461261  0.152559  2.52927



### push関数 / pop関数 (配列への要素の追加/削除)
配列の末尾に要素を追加する際には以前紹介した<b>push</b>を配列に関しても使用することができます。<br>
<b>push!(配列名, 末尾に追加したい要素名)</b><br>
と記述します。<br>
一方で、配列の末尾を削除する場合には<b>pop</b>を用います。


```julia
A = Vector(1:5)
#Aの末尾に0を追加
push!(A, 0)
```




    6-element Vector{Int64}:
     1
     2
     3
     4
     5
     0




```julia
#配列の末尾を削除
pop!(A)
A
```




    5-element Vector{Int64}:
     1
     2
     3
     4
     5



### reduce関数 (配列内の要素の和/積を計算する)
配列内の全ての要素の和/積を計算したい場合は<b>reduce関数</b>を用いて、<br>
<b>reduce(+, 和をとりたい配列名)</b><br>
<b>reduce(*, 積をとりたい配列名)</b><br>
と記述します。


```julia
A = Vector(1:5)
#配列Aのすべての要素の和を求める
reduce(+, A)
```




    15




```julia
A = Vector(1:5)
#配列Aのすべての要素の積を求める
reduce(*, A)
```




    120



### filter関数 (ある特定の条件を満たす要素を抜き出す)
配列から特定の条件を満たす要素を抜き出す場合には、<b>filter関数</b>を使って、配列を対象に評価式を作って値を抜き出します。<br>
<b>filter(評価式, 配列名)</b><br>
と記述します。


```julia
A = Vector(1:10)
#配列Aから奇数のみを取り出す
filter(isodd, A)
```




    5-element Vector{Int64}:
     1
     3
     5
     7
     9




```julia
A = Vector(1:10)
#配列Aから偶数のみを取り出す
filter(iseven, A)
```




    5-element Vector{Int64}:
      2
      4
      6
      8
     10



### size関数 / length関数 (配列の形状・要素数の取得)
配列の形状を取得する場合には、<b>size関数</b>、要素数を取得する場合には<b>length関数</b>を使用します。


```julia
A = Vector(1:10)
#配列の形状を取得
size(A)
```




    (10,)




```julia
A = Vector(1:10)
#配列の要素数を取得
length(A)
```




    10



### sort関数 (要素の並べ替え)
配列内の要素を並び替えたいときには<b>sort関数</b>を用いて、<br>
<b>sort(要素を昇順に並び替えたい配列名)</b><br>
<b>sort(要素を降順に並び替えたい配列名, rev=true)</b><br>
と記述します。


```julia
A = Vector(5:-1:1)
```




    5-element Vector{Int64}:
     5
     4
     3
     2
     1




```julia
#配列を昇順に並び替える
sort(A)
```




    5-element Vector{Int64}:
     1
     2
     3
     4
     5




```julia
#配列を降順に並び替える
sort(A, rev=true)
```




    5-element Vector{Int64}:
     5
     4
     3
     2
     1



# 5. 制御構造

## 5-1. if文

他の言語と同様、Juliaにもif文が存在します。ただし、if文の最後に<b>end</b>が必要になることに注意してください。<br>
また、下記の例ではインデントを付けて記述していますが、juliaの場合は<b>インデントを付けなくてもif文は動作</b>します。


```julia
name = "apple"
#nameがappleの際にはapple、それ以外の場合はelseを返すif文
if name == "apple"
    println("apple")
else
    println("else")
end
```

    apple
    


```julia
name = "banana"
#nameがappleの際にはapple、それ以外の場合はelseを返すif文
if name == "apple"
    println("apple")
else
    println("else")
end
```

    else
    

elseの中でさらに条件分岐をさせたい場合は、<b>elseif</b>を用います。


```julia
x = 1
y = 100
if x < y
    println("x < y")
elseif x > y
    println("x > y")
else
    println("x = y")
end
```

    x < y
    

## 5-2. 3項演算子
3項演算子を用いれば、かなり簡単にif文と同様の文を記述することができます。具体的には、<br>
<b>a ? b : c</b><br>
と記述し、<b>aの条件が真であればb、偽であればcを実行する</b>、という意味になります。


```julia
name = "banana"
#nameがappleであればtrue、それ以外であればfalseを返す
name == "apple" ? true : false
```




    false




```julia
name = "apple"
name == "apple" ? println("apple") : println("Not apple")
```

    apple
    

## 5-3. 短絡評価
### 短絡評価の基礎
<b>&&でand演算</b>を行い、<b>||でor演算</b>を行えます。


```julia
a = 1
b = 10
c = 5
#a<bかつb<cの時にtrueを返す
a < b && b < c
```




    false




```julia
a = 1
b = 10
c = 5
#a<bまたはb<cの時にtrueを返す
a < b || b < c
```




    true



### 短絡評価の応用
上記のような短絡評価を応用して、if文と同様の処理を行うことができます。


```julia
x = 10
#xが0より大きければ"x is larger than 0"を返し、そうでなければfalseを返す。
#&&は「かつ」なので、x>0がtrueでないと、その時点でfalseを返してしまうため、x>0でないと右側の命令を実行すらしない
x > 0 && println("x is larger than 0")
```

    x is larger than 0
    


```julia
x = -10
#xが0より大きければ"x is larger than 0"を返し、そうでなければfalseを返す。
#&&は「かつ」なので、x>0がtrueでないと、その時点でfalseを返してしまうため、x>0でないと右側の命令を実行すらしない
x > 0 && println("x is larger than 0")
```




    false




```julia
x = -10
#xが0より大きければ"x is larger than 0"を返し、そうでなければtrueを返す。
#||は「または」なのでx<0がtrueだと、そこでtrueを返してしまうため、右側の命令を実行すらしない
x < 0 || println("x is larger than 0")
```




    true




```julia
x = 10
#xが0より大きければ"x is larger than 0"を返し、そうでなければtrueを返す。
#||は「または」なのでx<0がtrueだと、そこでtrueを返してしまうため、右側の命令を実行すらしない
x < 0 || println("x is larger than 0")
```

    x is larger than 0
    

## 5-4. Forループ・Whileループ
他の言語と同様、Juliaにもループがあります。ただし、if文と同様、ループの最後に<b>end</b>を付けるのを忘れないようにしてください。
### forループ


```julia
#最初は0で、それに1を足し、2を足し、…、10を足し、それらの和の計算結果を表示する
a = 0
for i = 0:10
    a += i
    println("a=", a)
end
```

    a=0
    a=1
    a=3
    a=6
    a=10
    a=15
    a=21
    a=28
    a=36
    a=45
    a=55
    

上記のfor文ではイコール(=)で条件を記述しましたが、これはイコールの代わりに<b>in</b>でも大丈夫です。


```julia
#for分の条件はイコールの代わりにinでもOK
a = 0
for i in 0:10
    a += i
    println("a=", a)
end
```

    a=0
    a=1
    a=3
    a=6
    a=10
    a=15
    a=21
    a=28
    a=36
    a=45
    a=55
    

### whileループ
forループは何から何まで指定をし、その指定された区間をループさせますが、whileループはある条件を設定しその条件がfalseになるまで回し続ける挙動をします。


```julia
#iを0から1ずつ増やし、10を超えるまでループさせる
i = 0
while i < 10
    println(i)
    i += 1
end
```

    0
    1
    2
    3
    4
    5
    6
    7
    8
    9
    

### 様々なループの回し方
タプルやリスト、辞書を用いてループを回すこともできます。


```julia
#タプル内の要素でループさせる
a = ("one", "two", "three")
for i in a
    println(i)
end
```

    one
    two
    three
    


```julia
#リスt内の要素でループさせる
a = ["one", "two", "three"]
for i in a
    println(i)
end
```

    one
    two
    three
    


```julia
#辞書内の要素でループさせる
a = Dict(1 => "one", 2 => "two", 3 => "three")
#iでkey、jでvalueを回す
#$マークを用いて、iやjをprintの中に貼り込むことができる
for (i, j) in a
    println("$i は英語で$j です")
end
```

    2 は英語でtwo です
    3 は英語でthree です
    1 は英語でone です
    

複数のリストの情報をまとめて出力させることもできます。リストを同時に回す場合は<b>zip</b>を用います。


```julia
a = ["1", "2", "3"]
b = ["apple", "banana", "ｃherry"]
for (i, j) in zip(a, b)
    println("$j を$i 個ください")
end
```

    apple を1 個ください
    banana を2 個ください
    ｃherry を3 個ください
    

インデックスと要素を同時に受け取ることもできます。その場合は<b>enumerate関数</b>を用います。


```julia
#リストの要素とインデックスの両方をループさせる
b = ["apple", "banana", "ｃherry"]
for (index, fruit) in enumerate(b)
    println("$index は$fruit に対応します")
end
```

    1 はapple に対応します
    2 はbanana に対応します
    3 はｃherry に対応します
    

### 多重ループ
<b>多重ループ</b>もJuliaで行うことができます。Juliaの場合、多重ループは非常に簡単に表記できます。


```julia
for i = 1:5, j = 10:12
    println(i, ",", j)
end
```

    1,10
    1,11
    1,12
    2,10
    2,11
    2,12
    3,10
    3,11
    3,12
    4,10
    4,11
    4,12
    5,10
    5,11
    5,12
    

### ループを終わらせる
<b>break</b>を用いて、ループを終了させることができます


```julia
#iが5以上であればループを終了させ、そうでなければ1を足す
i = 0
while true
    println(i)
    if i >= 5
        break
    end
    i += 1
end
```

    0
    1
    2
    3
    4
    5
    

### ループを飛ばす
<b>continue</b>を用いることで、ループを飛ばして次のループに移動させることができます。


```julia
#iが3の時だけcontinueで飛ばす
for i = 1:5
    if i == 3
        continue
    end
    println(i)
end
```

    1
    2
    4
    5
    

## 5-5. 内包表記
ループを使ってリストや辞書型の変数を変えていくのが内包表記です。


```julia
#arrをforループを使って1から10までの要素を持つリストとして定義
arr = [n for n = 1:10]
```




    10-element Vector{Int64}:
      1
      2
      3
      4
      5
      6
      7
      8
      9
     10



内包表記では、ループに条件を付けることもできます。


```julia
#nが偶数の時のみという条件をつける
arr = [n for n = 1:10 if n % 2 == 0]
```




    5-element Vector{Int64}:
      2
      4
      6
      8
     10



辞書型についても内包表記が使えます。


```julia
#keyとvalueを指定して内包表記で辞書型を定義
fruits = Dict(i for i = zip(["apple", "banana", "cherry"], [0, 1, 2]))
```




    Dict{String, Int64} with 3 entries:
      "cherry" => 2
      "banana" => 1
      "apple"  => 0



# 6. 関数

## 6-1. 関数の定義
### 関数定義の基本
関数とは引数を入力したらそれに対して結果を返すオブジェクトのことです。関数は<b>function文</b>を使って定義します。


```julia
#引数に名前を入れると「hello 名前」と返す、helloという関数を定義する
function hello(name)
    return "Hello $(name)"
end
```




    hello (generic function with 1 method)




```julia
hello("Julia")
```




    "Hello Julia"



関数の戻り値を変数に直接入力することもできます。


```julia
#帰ってきたものを変数に入れる
h = hello("Ken")
```




    "Hello Ken"



### 一行で関数を定義
以下のように記述すれば、一行だけで関数を定義することもできます。この書き方であれば、functionもendもreturnも不要です。


```julia
hello(name) = "Hello $(name)"
```




    hello (generic function with 1 method)




```julia
hello("Julia")
```




    "Hello Julia"



数式の場合も同様に、以下のように知れば1行で関数を定義できます。


```julia
f(x, y, z) = x^2 + 3y - z/2
```




    f (generic function with 1 method)




```julia
f(2, 1, 4)
```




    5.0



また、以下のように記述しても関数を定義できます。


```julia
#引数を2乗する関数を定義
h = x -> x^2
```




    #5 (generic function with 1 method)




```julia
h(5)
```




    25



### 合成関数の定義
合成関数についての定義について説明します。以下のような合成関数を定義したい場合は、下のように記述します。<br>
$$
y = f(x) = x^2
$$
$$
g(y) = 3y + 1 
$$


```julia
gx = x -> (y -> 3y + 1)(x^2)
```




    #7 (generic function with 1 method)




```julia
gx(2)
```




    13



### 複数の返り値を持つ関数の定義
複数の返り値を持つ関数は以下のように定義します。ちなみに、返り値はタプル型となります。


```julia
#xとyの和と差を返す関数calcを定義
function calc(x, y)
    wa = x + y
    sa = x - y
    return wa, sa
end
```




    calc (generic function with 1 method)




```julia
calc(10, 5)
```




    (15, 5)




```julia
#返り値の型を確認
typeof(calc(10, 5))
```




    Tuple{Int64, Int64}



## 6-2. 可変長引数
### 可変長引数の扱い
これまでは引数の数は1つや2つなど固定の値でしたが、いくつ引数が入るかわからない場合には<b>可変長引数</b>を用います。<br>
可変長引数を扱う場合には...と記述し、好きなだけ引数を入れられるようにします。


```julia
#引数を...と書き、好きなだけ引数を入れられるようにする
function sum(x ...)
    s = 0
    #for文をxの数分だけ回す
    for i = 1:length(x)
        #xのi番目をsに足す
        s += x[i]
    end
    println(s)
end
```




    sum (generic function with 1 method)




```julia
sum(1, 5, 10)
```

    16
    

### 可変長引数と固定長引数が両方存在する場合の扱い


```julia
#固定長のaと可変長のxの両方を引数に取る関数を定義
function add(a, x ...)
    s = a
    #for文をxの数分だけ回す
    for i = 1:length(x)
        #xのi番目をsに足す
        s += x[i]
    end
    println(s)
end
```




    add (generic function with 1 method)




```julia
add(10, 1, 5, 10)
```

    26
    

### 固定長引数にデフォルト値を設定
固定長の引数にはデフォルト値を設定することもできます。ただし<b>デフォルトの値を指定する引数は最後に記述</b>しなければいけません。


```julia
#a=100をデフォルト値にするが、デフォルト値を持つ引数aはbよりも後に書く
function add2(b, a=100)
    x = a + b
    println(x)
end
```




    add2 (generic function with 2 methods)




```julia
#bのみ指定してもデフォルトのa=100とみなされて関数は機能する
add2(1)
```

    101
    


```julia
#個別に指定すればデフォルト値でない値を引数にすることもできる
add(1, 10)
```

    11
    

## 6-3. 多重ディスパッチ
同じ名前の引数で型の異なる関数がたくさんあった場合、実行するときに型に応じた関数が実行される仕組みにはJuliaには備わっており、これを多重ディスパッチと言います。(普通であれば、関数名が同じだとうまく作動しない)<br>
型の指定は<br>
<b>引数 :: 型名</b><br>
で行います。<br>
これはJulia特有の機能であり、他の言語には見られません。


```julia
#引数x(integer)をそのままreturnする関数を定義
function test(x :: Int64)
    return x
end
```




    test (generic function with 1 method)




```julia
#引数x(float)をそのままreturnする関数を定義
function test(x :: Float64)
    return x
end
```




    test (generic function with 2 methods)




```julia
#引数x(string)をそのままreturnする関数を定義
function test(x :: String)
    return x
end
```




    test (generic function with 3 methods)




```julia
#同じtest関数でも、引数の型から自動でstringのものを選択してくれる
test("Hello")
```




    "Hello"




```julia
test(1)
```




    1




```julia
test(3.14)
```




    3.14



# 7. モジュール

## 7-1. モジュール

### 名前空間
　プログラムを多数書いていると、各プログラムにおいて関数に同じ名前を付けてしまうことがあります。こういったことが発生するとエラーが起きるので、それらを避けるためには<b>名前空間</b>を用いる必要があります。名前空間を用いるとは、各ソースコードに名前を付けて識別していくことであり、それを行うためにJuliaでは<b>モジュール</b>を用います。<br>
　例えば、関数hogeが、モジュールA、モジュールB、モジュールCの中にそれぞれ入っているとします。普通は同名の関数が存在してしまうとエラーを起こしてしまうのでるが、モジュールの下に関数が入っている場合はそのモジュールを指定して、その下にある関数を呼び出すことで同名関数の存在を許すことができます。同じ名前であってもモジュールが異なれば名前空間が異なるため、関数を使用できるということです。

### 既存の標準モジュールを用いる
新たにモジュールを作成しなくても、先人達が作った既存のモジュールが存在します。例えば、よく使われるモジュールにstatisticsという平均や標準偏差などを求められるモジュールがあるのでそれを試しに使用してみます。<br>
モジュールは<b>using</b>を用いて呼び出します。


```julia
a = [1,2,3,4,5]
#Statisticsモジュールを呼び出す
using Statistics
#Statisticsモジュール内にあるmean(平均を求める)機能を使用する
mean(a)
```




    3.0



### 標準に備わっていないモジュールを用いる
標準モジュール以外のモジュールについてはインストールしてから使用する必要があります。インストールを行うモジュールは<b>Pkg</b>で、以下のように記述してインストールします。<br>
<b>using Pkg<br>
    Pkg.add("インストールしたいモジュール名")</b>


```julia
using Pkg
#randomパッケージをインストールする
Pkg.add("random")
```

    [32m[1m    Updating[22m[39m registry at `C:\Users\Riku Okawa\.julia\registries\General`
    [32m[1m    Updating[22m[39m git-repo `https://github.com/JuliaRegistries/General.git`
    


    The following package names could not be resolved:
     * random (not found in project, manifest or registry)
    

    

    Stacktrace:

      [1] pkgerror(msg::String)

        @ Pkg.Types C:\buildbot\worker\package_win64\build\usr\share\julia\stdlib\v1.6\Pkg\src\Types.jl:55

      [2] ensure_resolved(ctx::Pkg.Types.Context, pkgs::Vector{Pkg.Types.PackageSpec}; registry::Bool)

        @ Pkg.Types C:\buildbot\worker\package_win64\build\usr\share\julia\stdlib\v1.6\Pkg\src\Types.jl:862

      [3] add(ctx::Pkg.Types.Context, pkgs::Vector{Pkg.Types.PackageSpec}; preserve::Pkg.Types.PreserveLevel, platform::Base.BinaryPlatforms.Platform, kwargs::Base.Iterators.Pairs{Union{}, Union{}, Tuple{}, NamedTuple{(), Tuple{}}})

        @ Pkg.API C:\buildbot\worker\package_win64\build\usr\share\julia\stdlib\v1.6\Pkg\src\API.jl:186

      [4] add

        @ C:\buildbot\worker\package_win64\build\usr\share\julia\stdlib\v1.6\Pkg\src\API.jl:148 [inlined]

      [5] add(pkgs::Vector{Pkg.Types.PackageSpec}; kwargs::Base.Iterators.Pairs{Union{}, Union{}, Tuple{}, NamedTuple{(), Tuple{}}})

        @ Pkg.API C:\buildbot\worker\package_win64\build\usr\share\julia\stdlib\v1.6\Pkg\src\API.jl:73

      [6] add

        @ C:\buildbot\worker\package_win64\build\usr\share\julia\stdlib\v1.6\Pkg\src\API.jl:72 [inlined]

      [7] #add#21

        @ C:\buildbot\worker\package_win64\build\usr\share\julia\stdlib\v1.6\Pkg\src\API.jl:70 [inlined]

      [8] add

        @ C:\buildbot\worker\package_win64\build\usr\share\julia\stdlib\v1.6\Pkg\src\API.jl:70 [inlined]

      [9] #add#20

        @ C:\buildbot\worker\package_win64\build\usr\share\julia\stdlib\v1.6\Pkg\src\API.jl:69 [inlined]

     [10] add(pkg::String)

        @ Pkg.API C:\buildbot\worker\package_win64\build\usr\share\julia\stdlib\v1.6\Pkg\src\API.jl:69

     [11] top-level scope

        @ In[200]:3

     [12] eval

        @ .\boot.jl:360 [inlined]

     [13] include_string(mapexpr::typeof(REPL.softscope), mod::Module, code::String, filename::String)

        @ Base .\loading.jl:1094


### 自分でモジュールを定義する
標準モジュールでもなく、インストールするモジュールもない場合は地震でモジュールを定義することもできます。モジュールの定義には<b>module</b>を用いて、<br>
<b>module モジュール名<br>
関数<br>
end</b><br>
と記述します。


```julia
#my_helloというモジュールを定義する
module my_hello
#good_morningなどの関数をモジュール内で定義する
good_morning(name)=println("Good morning, $(name)！")
hello(name)=println("Hello, $(name)！")
good_afternoon(name)=println("Good afternoon, $(name)！")
end
```




    Main.my_hello




```julia
#my_hello内の関数を呼び出し使用する
my_hello.good_morning("Julia")
```

    Good morning, Julia！
    


```julia
#モジュールを指定せずに関数のみを使用するとエラーが出る
good_morning("Julia")
```


    UndefVarError: good_morning not defined

    

    Stacktrace:

     [1] top-level scope

       @ In[203]:2

     [2] eval

       @ .\boot.jl:360 [inlined]

     [3] include_string(mapexpr::typeof(REPL.softscope), mod::Module, code::String, filename::String)

       @ Base .\loading.jl:1094


# 8. ファイル入出力

## 8-1. ファイルへの書き込み

テキストファイルの作成を行う際には、最初はパスの設定を行います。パスの設定には<br>
<b>open("パス名+ファイル名", "w")</b><br>
と記述し（"w"はwrite、つまり書き込み可能なファイルを作成することを意味します）、<br>
<b>print(open("パス名+ファイル名", "w"), "書き込みたい内容")</b><br>
で書き込み。最後に<br>
<b>close(ファイル名)</b><br>
でファイルを閉じます。


```julia
#テキストファイルfを作成
file = open(".\\Julia_Scientific_Programming_for_Beginners/hello1.txt", "w")
#ファイルfに"Hello!"と書き込む
print(file, "Hello!")
#ファイルfを閉じる
close(file)
```


```julia
loc = ".\\Julia_Scientific_Programming_for_Beginners\\"
filename = "hello1.txt"
#指定したパスにある指定した名前のファイルを開く
file = open(loc*filename)
#どのような形式で読み込むのかを指定(今回はString(文字列型))
value = read(file, String)
```




    "Hello!"




```julia
#ファイルを閉じる
close(file)
```


```julia
#csvなど、tｘt以外のファイルも同様にして読み込める
loc = ".\\Julia_Scientific_Programming_for_Beginners\\"
filename = "temp_2019_tokyo.csv"
file = open(loc*filename)

#csvファイルの値を格納する配列を用意する
month = zeros(Int64, 0)
temperature = zeros(Float64, 0)
precipitation = zeros(Float64, 0)

#1行ずつStringで読み込み、文字列から数値へ型変換する
#この際、eachline関数を用いると便利
i = 0
for line in eachline(file)
    i += 1
    #1行目はheaderが入っているので飛ばす
    i == 1 && continue
    #カンマ区切りで分割する(csvファイルなので)
    s = split(line, ",")
    #sに入った3種のStringのデータをそれぞれ型変換する
    m = parse(Int64, s[1])
    push!(month, m)
    t = parse(Float64, s[2])
    push!(temperature, t)
    p = parse(Float64, s[3])
    push!(precipitation, p)
end 
   
println(month)
println(temperature)
println(precipitation)
close(file)
```

    [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
    [5.6, 7.2, 10.6, 13.6, 20.0, 21.8, 24.1, 28.4, 25.1, 19.4, 13.1, 8.5]
    [16.0, 42.0, 117.5, 90.5, 120.5, 225.0, 193.0, 110.0, 197.0, 529.5, 156.5, 76.5]
    

# 9. 可視化
## 9-1. 折れ線グラフ

### PyPlotなどの準備
プロットの作り方はいくつか方法がありますが、ここではPyPlotを用いたやり方を説明します。PyPlotはインストールする必要があります。


```julia
#PyPlotをインストール
using Pkg
Pkg.add("PyPlot")
```

    [32m[1m   Resolving[22m[39m package versions...
    [32m[1m  No Changes[22m[39m to `C:\Users\Riku Okawa\.julia\environments\v1.6\Project.toml`
    [32m[1m  No Changes[22m[39m to `C:\Users\Riku Okawa\.julia\environments\v1.6\Manifest.toml`
    


```julia
#FixedPointNumbersをインストール
using Pkg
Pkg.add("FixedPointNumbers")
```

    [32m[1m   Resolving[22m[39m package versions...
    [32m[1m  No Changes[22m[39m to `C:\Users\Riku Okawa\.julia\environments\v1.6\Project.toml`
    [32m[1m  No Changes[22m[39m to `C:\Users\Riku Okawa\.julia\environments\v1.6\Manifest.toml`
    


```julia
#ColorTypesをインストール
using Pkg
Pkg.add("ColorTypes")
```

    [32m[1m   Resolving[22m[39m package versions...
    [32m[1m  No Changes[22m[39m to `C:\Users\Riku Okawa\.julia\environments\v1.6\Project.toml`
    [32m[1m  No Changes[22m[39m to `C:\Users\Riku Okawa\.julia\environments\v1.6\Manifest.toml`
    


```julia
#PyPlotのversionを確認する
using PyPlot
PyPlot.version
```




    v"3.4.1"



### 描画の方法
折れ線グラフを描画する場合は、<br>
<b>plot(縦軸, 横軸, color=:線の色)</b><br>
と記述します。<br>
グラフのタイトルは、<br>
<b>title("タイトル名")</b><br>
軸の名前は<br>
<b>xlabel("x軸名")</b><br>
と記述します。<br>
なお、この際軸名に日本語を使うと文字化けしてしまうことがありますが、その場合は[こちらの記事](https://qiita.com/nyoi/items/d77aacad0f3ad997b60e)をご覧ください。


```julia
#折れ線グラフを描画する
ax = PyPlot.axes()

#軸と線の色を設定する
plot(month, temperature, color=:red)
title("Temperature")
xlabel("Month")
ylabel("Temperature [℃]")

#x軸のメモリを1ごとにする
Mx = matplotlib.ticker.MultipleLocator(1)
ax.xaxis.set_major_locator(Mx)
```


    
![png](output_339_0.png)
    


## 9-2. 棒グラフ
先ほどは平均気温をプロットしたので、今回は降水量をプロットしてみることにします。<br>
棒グラフは<b>bar</b>を用いて、<br>
<b>bar(縦軸, 横軸, color=:線の色)</b><br>
と記述します。グラフのタイトルや軸名の記述の方法は折れ線グラフの時と同様です。<br>
折れ線グラフの描画の時にはやりませんでしたが、軸の上限・下限の設定はy軸の場合は<b>ylim</b>を用い、<br>
<b>ylim(下限値, 上限値)</b><br>
と記述することで設定することができます。


```julia
#プロットを作成することを宣言
ax = PyPlot.axes()
#棒グラフを描画
b = bar(month, precipitation, color=:blue)
title("Precipitation")
xlabel("Month")
ylabel("Precipitation [mm]")

#x軸のメモリを1ごとにする
Mx = matplotlib.ticker.MultipleLocator(1)
ax.xaxis.set_major_locator(Mx)

#y軸の上限を設定する
ylim(0, 550)
```


    
![png](output_341_0.png)
    





    (0.0, 550.0)



## 9-3. 散布図
散布図は<b>scatter</b>を用い、<br>
<b>scatter(縦軸, 横軸, color=:点の色)</b><br>
と記述することで描画することができます。<br>
散布図はグリッドを付けると見やすい場合が多いですが、グリッドは<b>grid</b>を用い、<br>
<b>grid("on")</b><br>
と記述することで描画できます。


```julia
#横軸に平均気温、縦軸に降水量をとった際の散布図を作成する
#プロットを作成することを宣言
ax = PyPlot.axes()
scatter(temperature, precipitation, color=:green)
title("Scatter Plot")
xlabel("Temperature [℃]")
ylabel("Precipitation [mm]")
grid("on")
xlim(0, 30)
ylim(0, 600)
```


    
![png](output_343_0.png)
    





    (0.0, 600.0)



## 9-4. ヒストグラム
ヒストグラムは<b>hist</b>を用いて、<br>
<b>hist(値, ビンの数, color=:ヒストグラムの色)</b><br>
と記述することで描画できます。


```julia
#正規分布に従う乱数を発生
x = randn(10000)

#binの数を指定
nbins = 10

#ヒストグラムをプロット
hist(x, nbins, color=:magenta)
title("Title")
xlabel("x")
ylabel("y")
grid("on")
```


    
![png](output_345_0.png)
    


## 9-5. 1枚の図に複数のグラフ


```julia
#sinカーブとcosカーブを1枚の図に描く
x = range(0,2pi, length = 100)
#y=sin(x)のグラフを実線で描画
plot(x, sin.(x), "-", label = "sine", color = :purple)
#y=cos(x)のグラフを破線で描画
plot(x, cos.(x), "--", label = "cosine", color = :orange)
legend()
```


    
![png](output_347_0.png)
    





    PyObject <matplotlib.legend.Legend object at 0x000000006FC3C9A0>



## 9-6. 3Dプロット
3Dプロットを描画するには、まず描画対象を<b>collect</b>を用いて配列に変換します。<br>
その後、zも0で初期化した配列を用意し、<b>plot_surface</b>を用いて<br>
<b>plot_surface(x, y, z)</b><br>
と記述することで描画します。<br>
今回は$z = x^2 + y^2$のプロットを書いてみます。<br>


```julia
n = 30
x = range(-3, 3, length = n)
y = range(-3, 3, length = n)

#xとyを配列に変換する
xx = collect(x)
yy = collect(y)

#zも配列を用意し、0で初期化
z = zeros(n, n)

#z = x^2 + y^2
for i in 1:n
    for j in 1:n
        z[i, j] = xx[i]^2 + yy[j]^2
    end
end

#表示するグラフのサイズを指定(しなくともよい)
fig = figure("pyplot_surfaceplot", figsize = (10, 10))

#グラフを描画
plot_surface(xx, yy, z, color = :yellow)
xlabel("x")
ylabel("y")
zlabel("z")
```


    
![png](output_349_0.png)
    


    sys:1: MatplotlibDeprecationWarning: Calling gca() with keyword arguments was deprecated in Matplotlib 3.4. Starting two minor releases later, gca() will take no keyword arguments. The gca() function should only be used to get the current axes, or if no axes exist, create new axes with default keyword arguments. To create a new axes with non-default arguments, use plt.axes() or plt.subplot().





    PyObject Text(0.09332506951644351, 0.012503188505254637, 'z')



## 9-7. 複数プロットとファイルの保存
### 複数プロットの描画
プロットを複数描画する場合は、<b>subplot</b>を用いて、<br>
<b>subplot(行方向に何分割するか, 列方向に何分割するか, プロットに対応する番号)</b><br>
と記述します。
### プロットの保存
プロットを保存する際には<b>savefig</b>を用いて、<br>
<b>savefig("パス名+ファイル名")</b><br>
と記述します。


```julia
x = range(0, 2pi, length = 100)

#上側のプロットを作成
subplot(2, 1, 1)
plot(x, sin.(x), "-", label = "sine")
legend()

#下側のプロットを作成
subplot(2, 1, 2)
plot(x, cos.(x),"--", label = "cosine")
legend()

savefig(".\\Julia_Scientific_Programming_for_Beginners/image1.png")
```


    
![png](output_351_0.png)
    


# 10. データフレーム
## 10-1. データフレームの定義
### データフレームの作成
データフレームは二次元配置、つまり表形式でデータを持つためのフレームです。<br>
DataFrameは標準パッケージではないのでまずインストールしなければなりませんが、インストールが完了していればDataFrameを使用すると宣言し、<br>
<b>DataFrame(列名 = 列要素, 列名, 列要素, ……)</b><br>
と記述することで作成できます。


```julia
#データフレームのインストール
using Pkg
Pkg.add("DataFrames")
```

    [32m[1m   Resolving[22m[39m package versions...
    [32m[1m  No Changes[22m[39m to `C:\Users\Riku Okawa\.julia\environments\v1.6\Project.toml`
    [32m[1m  No Changes[22m[39m to `C:\Users\Riku Okawa\.julia\environments\v1.6\Manifest.toml`
    


```julia
using DataFrames
#A列とB列とそれぞれの中身を定義し、データフレームを作成
df = DataFrame(A = 1:5, B = ["Apple", "Banana", "Cherry", "Dorian", "Egg fruit"])
```




<table class="data-frame"><thead><tr><th></th><th>A</th><th>B</th></tr><tr><th></th><th>Int64</th><th>String</th></tr></thead><tbody><p>5 rows × 2 columns</p><tr><th>1</th><td>1</td><td>Apple</td></tr><tr><th>2</th><td>2</td><td>Banana</td></tr><tr><th>3</th><td>3</td><td>Cherry</td></tr><tr><th>4</th><td>4</td><td>Dorian</td></tr><tr><th>5</th><td>5</td><td>Egg fruit</td></tr></tbody></table>



各列の要素を見る場合には<br>
<b>データフレーム名.列名</b><br>
で調べることができます。(Array型で返ってきます)


```julia
#A列の要素を見る
df.A
```




    5-element Vector{Int64}:
     1
     2
     3
     4
     5




```julia
#列名はダブルクォーテーションで囲んでも同様に作動する
df."A"
```




    5-element Vector{Int64}:
     1
     2
     3
     4
     5



### データフレームの初期化
<b>DataFrame()</b>でデータフレームを初期化し、0×0の表にすることができます。


```julia
#データフレームを初期化
df = DataFrame()
```




<table class="data-frame"><thead><tr><th></th></tr><tr><th></th></tr></thead><tbody><p>0 rows × 0 columns</p></tbody></table>




```julia
#初期化したデータフレームに列を挿入
df.A = 1:8
df.A
```




    8-element Vector{Int64}:
     1
     2
     3
     4
     5
     6
     7
     8




```julia
df.B = ["A", "B", "C", "D", "E", "F", "G", "H"]
df
```




<table class="data-frame"><thead><tr><th></th><th>A</th><th>B</th></tr><tr><th></th><th>Int64</th><th>String</th></tr></thead><tbody><p>8 rows × 2 columns</p><tr><th>1</th><td>1</td><td>A</td></tr><tr><th>2</th><td>2</td><td>B</td></tr><tr><th>3</th><td>3</td><td>C</td></tr><tr><th>4</th><td>4</td><td>D</td></tr><tr><th>5</th><td>5</td><td>E</td></tr><tr><th>6</th><td>6</td><td>F</td></tr><tr><th>7</th><td>7</td><td>G</td></tr><tr><th>8</th><td>8</td><td>H</td></tr></tbody></table>



### データフレームの形の確認
データフレームの大きさを取得したい場合は、<br>
<b>size(データフレーム名)</b><br>
と入力すれば、データフレームの<b>(行数, 列数)</b>が返ってきます<br>
また、最後に1を付ければ行数のみが、2を付ければ列数のみが返ってきます


```julia
size(df)
```




    (8, 2)




```julia
#1列目の行数を確認
size(df, 1)
```




    8




```julia
#1列目の列数を確認
size(df, 2)
```




    2



## 10-2. データフレームの操作
### データ型の指定
データフレーム作成時には<br>
<b>列名 = 型[]</b><br>
と記述することで各列の型を指定することができます。


```julia
df = DataFrame(A = Int[], B = String[])
```




<table class="data-frame"><thead><tr><th></th><th>A</th><th>B</th></tr><tr><th></th><th>Int64</th><th>String</th></tr></thead><tbody><p>0 rows × 2 columns</p></tbody></table>



### 行の追加
行を追加するためには<b>push</b>を用いて、<br>
<b>push!(データフレーム名, (1列目に追加する要素, 2列目に追加する要素, ……))</b><br>
と記述します。


```julia
df = DataFrame(A = Int[], B = String[])
push!(df, (1, "Apple"))
push!(df, (2, "Banana"))
push!(df, (3, "Cherry"))
```




<table class="data-frame"><thead><tr><th></th><th>A</th><th>B</th></tr><tr><th></th><th>Int64</th><th>String</th></tr></thead><tbody><p>3 rows × 2 columns</p><tr><th>1</th><td>1</td><td>Apple</td></tr><tr><th>2</th><td>2</td><td>Banana</td></tr><tr><th>3</th><td>3</td><td>Cherry</td></tr></tbody></table>



### 行の削除
行を削除する場合は<b>delete</b>を用いて、<br>
<b>delete!(データフレーム名, 削除したい行数)</b><br>
と記述します。


```julia
delete!(df, 3)
```




<table class="data-frame"><thead><tr><th></th><th>A</th><th>B</th></tr><tr><th></th><th>Int64</th><th>String</th></tr></thead><tbody><p>2 rows × 2 columns</p><tr><th>1</th><td>1</td><td>Apple</td></tr><tr><th>2</th><td>2</td><td>Banana</td></tr></tbody></table>



### 行の取得
最初の行を取得する場合は<b>first</b>を用い、<br>
<b>first(データフレーム名, 最初の何行を取得したいか)</b><br>
と記述し、<br>
最後の行を取得する場合は<b>last</b>を用い、<br>
<b>last(データフレーム名, 最後の何行を取得したいか)</b><br>
と記述します。<br>
また、スライスもpythonなどと同様に使用でき<br>
<b>データフレーム名[取得したい最初の行:取得したい最後の行, 取得したい最初の列:取得したい最後の列]</b><br>
と記述することで、データフレームを切り出せます。


```julia
#新しいデータフレームを作成
df = DataFrame(A = 0:5:95, B = repeat(1:10, inner = 2), C = 1:20)
```




<table class="data-frame"><thead><tr><th></th><th>A</th><th>B</th><th>C</th></tr><tr><th></th><th>Int64</th><th>Int64</th><th>Int64</th></tr></thead><tbody><p>20 rows × 3 columns</p><tr><th>1</th><td>0</td><td>1</td><td>1</td></tr><tr><th>2</th><td>5</td><td>1</td><td>2</td></tr><tr><th>3</th><td>10</td><td>2</td><td>3</td></tr><tr><th>4</th><td>15</td><td>2</td><td>4</td></tr><tr><th>5</th><td>20</td><td>3</td><td>5</td></tr><tr><th>6</th><td>25</td><td>3</td><td>6</td></tr><tr><th>7</th><td>30</td><td>4</td><td>7</td></tr><tr><th>8</th><td>35</td><td>4</td><td>8</td></tr><tr><th>9</th><td>40</td><td>5</td><td>9</td></tr><tr><th>10</th><td>45</td><td>5</td><td>10</td></tr><tr><th>11</th><td>50</td><td>6</td><td>11</td></tr><tr><th>12</th><td>55</td><td>6</td><td>12</td></tr><tr><th>13</th><td>60</td><td>7</td><td>13</td></tr><tr><th>14</th><td>65</td><td>7</td><td>14</td></tr><tr><th>15</th><td>70</td><td>8</td><td>15</td></tr><tr><th>16</th><td>75</td><td>8</td><td>16</td></tr><tr><th>17</th><td>80</td><td>9</td><td>17</td></tr><tr><th>18</th><td>85</td><td>9</td><td>18</td></tr><tr><th>19</th><td>90</td><td>10</td><td>19</td></tr><tr><th>20</th><td>95</td><td>10</td><td>20</td></tr></tbody></table>




```julia
#最初の行を取得する
first(df, 3)
```




<table class="data-frame"><thead><tr><th></th><th>A</th><th>B</th><th>C</th></tr><tr><th></th><th>Int64</th><th>Int64</th><th>Int64</th></tr></thead><tbody><p>3 rows × 3 columns</p><tr><th>1</th><td>0</td><td>1</td><td>1</td></tr><tr><th>2</th><td>5</td><td>1</td><td>2</td></tr><tr><th>3</th><td>10</td><td>2</td><td>3</td></tr></tbody></table>




```julia
#最後の行を取得する
last(df, 3)
```




<table class="data-frame"><thead><tr><th></th><th>A</th><th>B</th><th>C</th></tr><tr><th></th><th>Int64</th><th>Int64</th><th>Int64</th></tr></thead><tbody><p>3 rows × 3 columns</p><tr><th>1</th><td>85</td><td>9</td><td>18</td></tr><tr><th>2</th><td>90</td><td>10</td><td>19</td></tr><tr><th>3</th><td>95</td><td>10</td><td>20</td></tr></tbody></table>




```julia
#1行目から10行目を取得する
df[1:10,:]
```




<table class="data-frame"><thead><tr><th></th><th>A</th><th>B</th><th>C</th></tr><tr><th></th><th>Int64</th><th>Int64</th><th>Int64</th></tr></thead><tbody><p>10 rows × 3 columns</p><tr><th>1</th><td>0</td><td>1</td><td>1</td></tr><tr><th>2</th><td>5</td><td>1</td><td>2</td></tr><tr><th>3</th><td>10</td><td>2</td><td>3</td></tr><tr><th>4</th><td>15</td><td>2</td><td>4</td></tr><tr><th>5</th><td>20</td><td>3</td><td>5</td></tr><tr><th>6</th><td>25</td><td>3</td><td>6</td></tr><tr><th>7</th><td>30</td><td>4</td><td>7</td></tr><tr><th>8</th><td>35</td><td>4</td><td>8</td></tr><tr><th>9</th><td>40</td><td>5</td><td>9</td></tr><tr><th>10</th><td>45</td><td>5</td><td>10</td></tr></tbody></table>




```julia
#Aが50より大きいものだけ取得する
df[df.A .> 50, :]
```




<table class="data-frame"><thead><tr><th></th><th>A</th><th>B</th><th>C</th></tr><tr><th></th><th>Int64</th><th>Int64</th><th>Int64</th></tr></thead><tbody><p>9 rows × 3 columns</p><tr><th>1</th><td>55</td><td>6</td><td>12</td></tr><tr><th>2</th><td>60</td><td>7</td><td>13</td></tr><tr><th>3</th><td>65</td><td>7</td><td>14</td></tr><tr><th>4</th><td>70</td><td>8</td><td>15</td></tr><tr><th>5</th><td>75</td><td>8</td><td>16</td></tr><tr><th>6</th><td>80</td><td>9</td><td>17</td></tr><tr><th>7</th><td>85</td><td>9</td><td>18</td></tr><tr><th>8</th><td>90</td><td>10</td><td>19</td></tr><tr><th>9</th><td>95</td><td>10</td><td>20</td></tr></tbody></table>



### サマリの確認
データフレームのサマリを確認するには<b>describe</b>を用いて、<br>
<b>describe(データフレーム名)</b>
と記述すると取得できます。


```julia
describe(df)
```




<table class="data-frame"><thead><tr><th></th><th>variable</th><th>mean</th><th>min</th><th>median</th><th>max</th><th>nmissing</th><th>eltype</th></tr><tr><th></th><th>Symbol</th><th>Float64</th><th>Int64</th><th>Float64</th><th>Int64</th><th>Int64</th><th>DataType</th></tr></thead><tbody><p>3 rows × 7 columns</p><tr><th>1</th><td>A</td><td>47.5</td><td>0</td><td>47.5</td><td>95</td><td>0</td><td>Int64</td></tr><tr><th>2</th><td>B</td><td>5.5</td><td>1</td><td>5.5</td><td>10</td><td>0</td><td>Int64</td></tr><tr><th>3</th><td>C</td><td>10.5</td><td>1</td><td>10.5</td><td>20</td><td>0</td><td>Int64</td></tr></tbody></table>



### 列の削除
列を削除する場合は、<b>select</b>を用いて、<br>
<b>select(データフレーム名, Not(:カラム名))</b><br>
もしくは、<br>
<b>select!(データフレーム名, Not(:カラム名))</b><br>
と記述します。<br>
後者の記述方法は元のデータフレームからも列を削除してしまうことになります。


```julia
#列Bを削除
select(df, Not(:B))
```




<table class="data-frame"><thead><tr><th></th><th>A</th><th>C</th></tr><tr><th></th><th>Int64</th><th>Int64</th></tr></thead><tbody><p>20 rows × 2 columns</p><tr><th>1</th><td>0</td><td>1</td></tr><tr><th>2</th><td>5</td><td>2</td></tr><tr><th>3</th><td>10</td><td>3</td></tr><tr><th>4</th><td>15</td><td>4</td></tr><tr><th>5</th><td>20</td><td>5</td></tr><tr><th>6</th><td>25</td><td>6</td></tr><tr><th>7</th><td>30</td><td>7</td></tr><tr><th>8</th><td>35</td><td>8</td></tr><tr><th>9</th><td>40</td><td>9</td></tr><tr><th>10</th><td>45</td><td>10</td></tr><tr><th>11</th><td>50</td><td>11</td></tr><tr><th>12</th><td>55</td><td>12</td></tr><tr><th>13</th><td>60</td><td>13</td></tr><tr><th>14</th><td>65</td><td>14</td></tr><tr><th>15</th><td>70</td><td>15</td></tr><tr><th>16</th><td>75</td><td>16</td></tr><tr><th>17</th><td>80</td><td>17</td></tr><tr><th>18</th><td>85</td><td>18</td></tr><tr><th>19</th><td>90</td><td>19</td></tr><tr><th>20</th><td>95</td><td>20</td></tr></tbody></table>



### 列名の変更
列の削除と同様<b>select</b>を用いて、<br>
<b>select(データフレーム名, :変更したいカラム名 => :変更後のカラム名)</b><br>
もしくは、<br>
<b>select!(データフレーム名, :変更したいカラム名 => :変更後のカラム名)</b><br>
と記述します。<br>
後者の記述方法は元のデータフレームの列名も変更することになります。


```julia
#A列をAA、C列をCCに改名する
select(df, :A => :AA, :C => :CC)
```




<table class="data-frame"><thead><tr><th></th><th>AA</th><th>CC</th></tr><tr><th></th><th>Int64</th><th>Int64</th></tr></thead><tbody><p>20 rows × 2 columns</p><tr><th>1</th><td>0</td><td>1</td></tr><tr><th>2</th><td>5</td><td>2</td></tr><tr><th>3</th><td>10</td><td>3</td></tr><tr><th>4</th><td>15</td><td>4</td></tr><tr><th>5</th><td>20</td><td>5</td></tr><tr><th>6</th><td>25</td><td>6</td></tr><tr><th>7</th><td>30</td><td>7</td></tr><tr><th>8</th><td>35</td><td>8</td></tr><tr><th>9</th><td>40</td><td>9</td></tr><tr><th>10</th><td>45</td><td>10</td></tr><tr><th>11</th><td>50</td><td>11</td></tr><tr><th>12</th><td>55</td><td>12</td></tr><tr><th>13</th><td>60</td><td>13</td></tr><tr><th>14</th><td>65</td><td>14</td></tr><tr><th>15</th><td>70</td><td>15</td></tr><tr><th>16</th><td>75</td><td>16</td></tr><tr><th>17</th><td>80</td><td>17</td></tr><tr><th>18</th><td>85</td><td>18</td></tr><tr><th>19</th><td>90</td><td>19</td></tr><tr><th>20</th><td>95</td><td>20</td></tr></tbody></table>




```julia
#先のコードではselectに!を付けていないため、元のdfに変更はない
df
```




<table class="data-frame"><thead><tr><th></th><th>A</th><th>B</th><th>C</th></tr><tr><th></th><th>Int64</th><th>Int64</th><th>Int64</th></tr></thead><tbody><p>20 rows × 3 columns</p><tr><th>1</th><td>0</td><td>1</td><td>1</td></tr><tr><th>2</th><td>5</td><td>1</td><td>2</td></tr><tr><th>3</th><td>10</td><td>2</td><td>3</td></tr><tr><th>4</th><td>15</td><td>2</td><td>4</td></tr><tr><th>5</th><td>20</td><td>3</td><td>5</td></tr><tr><th>6</th><td>25</td><td>3</td><td>6</td></tr><tr><th>7</th><td>30</td><td>4</td><td>7</td></tr><tr><th>8</th><td>35</td><td>4</td><td>8</td></tr><tr><th>9</th><td>40</td><td>5</td><td>9</td></tr><tr><th>10</th><td>45</td><td>5</td><td>10</td></tr><tr><th>11</th><td>50</td><td>6</td><td>11</td></tr><tr><th>12</th><td>55</td><td>6</td><td>12</td></tr><tr><th>13</th><td>60</td><td>7</td><td>13</td></tr><tr><th>14</th><td>65</td><td>7</td><td>14</td></tr><tr><th>15</th><td>70</td><td>8</td><td>15</td></tr><tr><th>16</th><td>75</td><td>8</td><td>16</td></tr><tr><th>17</th><td>80</td><td>9</td><td>17</td></tr><tr><th>18</th><td>85</td><td>9</td><td>18</td></tr><tr><th>19</th><td>90</td><td>10</td><td>19</td></tr><tr><th>20</th><td>95</td><td>10</td><td>20</td></tr></tbody></table>



## 10-3. データフレームを用いたCSV読み書きとプロット
### csvの読み込み
csvは標準で備わっているものではないので、別途インストールする必要があります。<br>
インストール後は、<br>
<b>CSV.read(パス名+ファイル名, DataFrame, header = true, delim = ",")</b><br> 
と記述すれば、読み込みことができます。
header = trueはヘッダーが存在していること、delim = ","はデータがカンマ区切りになっていることを伝えるものです。


```julia
#CSVをインストール
using Pkg
Pkg.add("CSV")
```

    [32m[1m   Resolving[22m[39m package versions...
    [32m[1m  No Changes[22m[39m to `C:\Users\Riku Okawa\.julia\environments\v1.6\Project.toml`
    [32m[1m  No Changes[22m[39m to `C:\Users\Riku Okawa\.julia\environments\v1.6\Manifest.toml`
    


```julia
using CSV
loc = ".\\Julia_Scientific_Programming_for_Beginners\\"
filename = "temp_2019_tokyo.csv"
df = CSV.read(loc * filename, DataFrame, header = true, delim = ",")
```




<table class="data-frame"><thead><tr><th></th><th>月</th><th>平均気温</th><th>降水量の合計</th></tr><tr><th></th><th>Int64</th><th>Float64</th><th>Float64</th></tr></thead><tbody><p>12 rows × 3 columns</p><tr><th>1</th><td>1</td><td>5.6</td><td>16.0</td></tr><tr><th>2</th><td>2</td><td>7.2</td><td>42.0</td></tr><tr><th>3</th><td>3</td><td>10.6</td><td>117.5</td></tr><tr><th>4</th><td>4</td><td>13.6</td><td>90.5</td></tr><tr><th>5</th><td>5</td><td>20.0</td><td>120.5</td></tr><tr><th>6</th><td>6</td><td>21.8</td><td>225.0</td></tr><tr><th>7</th><td>7</td><td>24.1</td><td>193.0</td></tr><tr><th>8</th><td>8</td><td>28.4</td><td>110.0</td></tr><tr><th>9</th><td>9</td><td>25.1</td><td>197.0</td></tr><tr><th>10</th><td>10</td><td>19.4</td><td>529.5</td></tr><tr><th>11</th><td>11</td><td>13.1</td><td>156.5</td></tr><tr><th>12</th><td>12</td><td>8.5</td><td>76.5</td></tr></tbody></table>



### csvファイルのデータのプロット
以前はPyPlotを用いてデータをプロットしましたが、データフレーム形式では
PyPlotを使用できないため、プロットを行う場合は<b>StatsPlots</b>を使用する必要があります。


```julia
Pkg.add("StatsPlots")
```

    [32m[1m   Resolving[22m[39m package versions...
    [32m[1m  No Changes[22m[39m to `C:\Users\Riku Okawa\.julia\environments\v1.6\Project.toml`
    [32m[1m  No Changes[22m[39m to `C:\Users\Riku Okawa\.julia\environments\v1.6\Manifest.toml`
    


```julia
using DataFrames
using CSV
loc = ".\\Julia_Scientific_Programming_for_Beginners\\"
filename = "temp_2019_tokyo.csv"
df = CSV.read(loc * filename, DataFrame, header = true, delim = ",")

using StatsPlots
#横軸を月、縦軸を平均気温としてdfとしてプロット

@df df plot(:月, :平均気温
    ,title = "Temperature"
    ,xlabel = "Month"
    ,ylabel = "Temperature [℃]"
    #x軸のメモリを0から1刻みで12までに変更
    ,xtick = 0:1:12
    #y軸のメモリを0から5刻みで30までに変更
    ,ytick = 0:5:30
    ,label = "Temp"
    ,color = :red
    #各データポイントに丸を付ける
    ,shape = :circle)
```




    
![svg](output_390_0.svg)
    



### CSVへの書き出し
CSVへの出力は<b>write</b>を用いて、<br>
<b>CSV.write(パス名 + ファイル名, df)</b><br>
と記述することで行うことができます。


```julia
#データフレームを作成
df = DataFrame(A = 0:5:95, B = repeat(1:10, inner = 2), C = 1:20)
```




<table class="data-frame"><thead><tr><th></th><th>A</th><th>B</th><th>C</th></tr><tr><th></th><th>Int64</th><th>Int64</th><th>Int64</th></tr></thead><tbody><p>20 rows × 3 columns</p><tr><th>1</th><td>0</td><td>1</td><td>1</td></tr><tr><th>2</th><td>5</td><td>1</td><td>2</td></tr><tr><th>3</th><td>10</td><td>2</td><td>3</td></tr><tr><th>4</th><td>15</td><td>2</td><td>4</td></tr><tr><th>5</th><td>20</td><td>3</td><td>5</td></tr><tr><th>6</th><td>25</td><td>3</td><td>6</td></tr><tr><th>7</th><td>30</td><td>4</td><td>7</td></tr><tr><th>8</th><td>35</td><td>4</td><td>8</td></tr><tr><th>9</th><td>40</td><td>5</td><td>9</td></tr><tr><th>10</th><td>45</td><td>5</td><td>10</td></tr><tr><th>11</th><td>50</td><td>6</td><td>11</td></tr><tr><th>12</th><td>55</td><td>6</td><td>12</td></tr><tr><th>13</th><td>60</td><td>7</td><td>13</td></tr><tr><th>14</th><td>65</td><td>7</td><td>14</td></tr><tr><th>15</th><td>70</td><td>8</td><td>15</td></tr><tr><th>16</th><td>75</td><td>8</td><td>16</td></tr><tr><th>17</th><td>80</td><td>9</td><td>17</td></tr><tr><th>18</th><td>85</td><td>9</td><td>18</td></tr><tr><th>19</th><td>90</td><td>10</td><td>19</td></tr><tr><th>20</th><td>95</td><td>10</td><td>20</td></tr></tbody></table>




```julia
loc = ".\\Julia_Scientific_Programming_for_Beginners\\"
filename = "output_dataframe.csv"
CSV.write(loc * filename, df)
```




    ".\\Julia_Scientific_Programming_for_Beginners\\output_dataframe.csv"



# 11. 科学計算
## 11-1. 配列の操作
### ベクトルの行列への拡張


```julia
#ベクトルを作成
a = Vector(1:3)
b = Vector(4:6)

#2つのベクトルを結合し、3×2の配列を作成
[a b]
```




    3×2 Matrix{Int64}:
     1  4
     2  5
     3  6



### 配列の要素へのアクセス


```julia
#多次元配列(3×3)を作成
A = [1 2 3; 4 5 6; 7 8 9]

#2行3列目の要素を取得
A[2:3]
```




    2-element Vector{Int64}:
     4
     7



### 配列の最初と最後の要素の取得


```julia
#1次元配列を作成
A = Vector(1:9)

#配列の最初の要素を取得
A[begin]
```




    1




```julia
#配列の最後の要素を取得
A[end]
```




    9



### 配列への代入
配列の代入は、<br>
<b>配列名[代入したいか所] = 代入したい値</b><br>
と記述することで行えます。<br>
また、全ての要素に対して影響を与えたい場合は、<br>
<b>配列名 .与えたい操作</b><br>
と記述します。


```julia
a = Vector(1:9)
#配列の2番目に0を代入
a[2] = 0
a
```




    9-element Vector{Int64}:
     1
     0
     3
     4
     5
     6
     7
     8
     9




```julia
#配列のすべての要素に1を足す
a .+ 1
```




    9-element Vector{Int64}:
      2
      1
      4
      5
      6
      7
      8
      9
     10




```julia
#aの値が4より大きい場合に0にする
a[a .> 4] .= 0
a
```




    9-element Vector{Int64}:
     1
     0
     3
     4
     0
     0
     0
     0
     0



### reshape関数を用いた多次元配列の作成
<b>resphape関数</b>を用いて多次元配列を作成するには、<br>
<b>reshape(配列の要素, 行数, 列数)</b><br>
と記述します。<br>
reshape関数によって作成された配列はreshapeオブジェクトとして返ってきます。<br>
<b>reshapeオブジェクトには代入は行えません。</b><br>
代入を行いたい場合はcolllectもしくはArray関数を用いて<b>配列に直してから行っ</b>てください。


```julia
A= reshape(1:9, 3, 3)
```




    3×3 reshape(::UnitRange{Int64}, 3, 3) with eltype Int64:
     1  4  7
     2  5  8
     3  6  9




```julia
#reshapeオブジェクトは代入ができない
A[3, 3] = 9
```


    indexed assignment fails for a reshaped range; consider calling collect

    

    Stacktrace:

     [1] error(s::String)

       @ Base .\error.jl:33

     [2] _rs_setindex!_err()

       @ Base .\reshapedarray.jl:279

     [3] setindex!(::Base.ReshapedArray{Int64, 2, UnitRange{Int64}, Tuple{}}, ::Int64, ::Int64, ::Int64)

       @ Base .\reshapedarray.jl:276

     [4] top-level scope

       @ In[255]:2

     [5] eval

       @ .\boot.jl:360 [inlined]

     [6] include_string(mapexpr::typeof(REPL.softscope), mod::Module, code::String, filename::String)

       @ Base .\loading.jl:1094



```julia
#reshapeオブジェクトをarrayに変換
collect(A)
```




    3×3 Matrix{Int64}:
     1  4  7
     2  5  8
     3  6  9



### サブ配列
配列の一部を表すためのオブジェクトであるサブ配列は、<b>view関数</b>を用いて<br>
<b>view(配列名, 行番号 , 列番号)</b><br>
と記述することで作成できます。<br>
サブ配列は元の配列を参照しているにすぎないので、<b>元の配列が変更されればサブ配列も同時に変更されます</b>。<br>
サブ配列は大規模な配列から一部を取り出して参照したい際に非常に便利です。


```julia
#一様分布に従う配列を作成
A = rand(3,3)

#1列目のみを取り出したサブ配列を作成
view(A, :, 1)
```




    3-element view(::Matrix{Float64}, :, 1) with eltype Float64:
     0.17795032398514676
     0.4752769483314607
     0.3417266834798147




```julia
#配列を更新するとviewも更新される
A = collect(reshape(1:9, 3, 3))
view(A, :, 1)
```




    3-element view(::Matrix{Int64}, :, 1) with eltype Int64:
     1
     2
     3



## 11-2. 行列とベクトル
### 要素同士の演算
ベクトル同士の演算にはブロードキャスト、つまり演算子の前にピリオドが必要となります


```julia
#ベクトルを作成
a = Vector(1:3)
b = Vector(4:6)

#演算子の前にピリオドがないとエラーとなる
a * b
```


    MethodError: no method matching *(::Vector{Int64}, ::Vector{Int64})
    Closest candidates are:
      *(::Any, ::Any, ::Any, ::Any...) at operators.jl:560
      *(::StridedMatrix{T}, ::StridedVector{S}) where {T<:Union{Float32, Float64, ComplexF32, ComplexF64}, S<:Real} at C:\buildbot\worker\package_win64\build\usr\share\julia\stdlib\v1.6\LinearAlgebra\src\matmul.jl:44
      *(::StridedVecOrMat{T} where T, ::LinearAlgebra.Adjoint{var"#s832", var"#s831"} where {var"#s832", var"#s831"<:LinearAlgebra.LQPackedQ}) at C:\buildbot\worker\package_win64\build\usr\share\julia\stdlib\v1.6\LinearAlgebra\src\lq.jl:254
      ...

    

    Stacktrace:

     [1] top-level scope

       @ In[259]:6

     [2] eval

       @ .\boot.jl:360 [inlined]

     [3] include_string(mapexpr::typeof(REPL.softscope), mod::Module, code::String, filename::String)

       @ Base .\loading.jl:1094



```julia
#ベクトルの要素同士を掛け算
a .* b
```




    3-element Vector{Int64}:
      4
     10
     18



### 内積の計算
内積計算<b>LinearAlgebra</b>という線形代数のライブラリを用います。<br>
内積計算は<br>
<b>ベクトル名 ⋅ベクトル名</b><br>
と記述することで計算できるが、内積計算を表す ⋅は<br>
<b>\cdotとタイプしTabキーを押す</b><br>
ことで書けます。<br>
また、<b>dot関数</b>を用いて<br>
<b>dot(ベクトル名, ベクトル名)</b><br>
と記述することでも同様に計算できます。


```julia
using LinearAlgebra
#aとｂの内積を計算
a ⋅b
```




    32




```julia
#dot関数でも内積を計算できる
dot(a, b)
```




    32




```julia
#ベクトルaを転置して掛け算することは、aとbの内積を計算することと同値になる
transpose(a) * b
```




    32




```julia
#ｂを転置して掛け算を行うと内積ではなく直積が計算される
a * transpose(b)
```




    3×3 Matrix{Int64}:
      4   5   6
      8  10  12
     12  15  18



### 単位行列
単位行列はLinearAlgebra内の<br>
<b>Matrix(1.0I, 行数, 列数)</b><br>
と記述することで作成できます。


```julia
using LinearAlgebra
#3×3の単位行列を作成
Matrix(1.0I, 3, 3)
```




    3×3 Matrix{Float64}:
     1.0  0.0  0.0
     0.0  1.0  0.0
     0.0  0.0  1.0




```julia
#Arrayを使っても同様に単位行列を作成できる
Array(1I, 3, 3)
```




    3×3 Matrix{Int64}:
     1  0  0
     0  1  0
     0  0  1



### 行列のスカラー倍
スカラー倍はドット演算子を用いて<br>
<b>行列名 .* 倍数</b><br>
と記述することで行えます。


```julia
A = Array(reshape(1:9, 3, 3))
c = 2

#Aを2倍する
A .* c
```




    3×3 Matrix{Int64}:
     2   8  14
     4  10  16
     6  12  18




```julia
#行列とベクトルの積にはドットは不要
A = Array(reshape(1:9, 3, 3))
v = Vector(1:3)
A * v
```




    3-element Vector{Int64}:
     30
     36
     42




```julia
#次元が合わない行列の掛け算を実行しようとするとDimensionMismatchエラーとなる
v * A
```


    DimensionMismatch("matrix A has dimensions (3,1), matrix B has dimensions (3,3)")

    

    Stacktrace:

     [1] _generic_matmatmul!(C::Matrix{Int64}, tA::Char, tB::Char, A::Matrix{Int64}, B::Matrix{Int64}, _add::LinearAlgebra.MulAddMul{true, true, Bool, Bool})

       @ LinearAlgebra C:\buildbot\worker\package_win64\build\usr\share\julia\stdlib\v1.6\LinearAlgebra\src\matmul.jl:814

     [2] generic_matmatmul!(C::Matrix{Int64}, tA::Char, tB::Char, A::Matrix{Int64}, B::Matrix{Int64}, _add::LinearAlgebra.MulAddMul{true, true, Bool, Bool})

       @ LinearAlgebra C:\buildbot\worker\package_win64\build\usr\share\julia\stdlib\v1.6\LinearAlgebra\src\matmul.jl:802

     [3] mul!

       @ C:\buildbot\worker\package_win64\build\usr\share\julia\stdlib\v1.6\LinearAlgebra\src\matmul.jl:302 [inlined]

     [4] mul!

       @ C:\buildbot\worker\package_win64\build\usr\share\julia\stdlib\v1.6\LinearAlgebra\src\matmul.jl:275 [inlined]

     [5] *

       @ C:\buildbot\worker\package_win64\build\usr\share\julia\stdlib\v1.6\LinearAlgebra\src\matmul.jl:153 [inlined]

     [6] *(a::Vector{Int64}, B::Matrix{Int64})

       @ LinearAlgebra C:\buildbot\worker\package_win64\build\usr\share\julia\stdlib\v1.6\LinearAlgebra\src\matmul.jl:63

     [7] top-level scope

       @ In[269]:2

     [8] eval

       @ .\boot.jl:360 [inlined]

     [9] include_string(mapexpr::typeof(REPL.softscope), mod::Module, code::String, filename::String)

       @ Base .\loading.jl:1094


### 行列同士の積
行列の席は<br>
<b>行列名 * 行列名</b><br>
で計算することができます。


```julia
A = Array(reshape(1:9, 3, 3))
B = fill(2, 3, 3)
A * B
```




    3×3 Matrix{Int64}:
     24  24  24
     30  30  30
     36  36  36



### 転置行列
行列を転置させたい場合には、<br>
<b>transpose(行列名)</b><br>
もしくは、<br>
<b>行列名'</b><br>
と記述します。


```julia
A = Array(reshape(1:9, 3, 3))
transpose(A)
```




    3×3 transpose(::Matrix{Int64}) with eltype Int64:
     1  2  3
     4  5  6
     7  8  9




```julia
A = Array(reshape(1:9, 3, 3))
A'
```




    3×3 adjoint(::Matrix{Int64}) with eltype Int64:
     1  2  3
     4  5  6
     7  8  9



### トレース計算
トレース(対角成分の和)は<br>
<b>tr(行列名)</b><br>
と記述することで計算できます。


```julia
A = Array(reshape(1:9, 3, 3))
tr(A)
```




    15



### 行列式の計算
行列式は<br>
<b>det(行列名)</b><br>
と記述することで計算できます


```julia
A = [1 2 3; 4 1 6; 7 8 1]
det(A)
```




    104.0



### 逆行列の計算
逆行列は<br>
<b>inv(行列名)</b><br>
と記述することで計算できます


```julia
A = [1 2 3; 4 1 6; 7 8 1]
inv(A)
```




    3×3 Matrix{Float64}:
     -0.451923   0.211538    0.0865385
      0.365385  -0.192308    0.0576923
      0.240385   0.0576923  -0.0673077




```julia
#元の行列と逆行列を掛けると単位行列になるため、正しく計算が行われていることがわかる
A * inv(A)
```




    3×3 Matrix{Float64}:
      1.0           0.0          -2.77556e-17
     -2.22045e-16   1.0           0.0
      3.88578e-16  -1.38778e-17   1.0



### 連立一次方程式を解く
逆行列を用いても計算できますが、LinearAlgebraのパッケージ内に簡単に計算できる機能が備わっています。<br>
Ax = bの買いを求める場合は、<br>
<b>A \ b</b><br>
と記述します。


```julia
using LinearAlgebra
A = [1 2 3; 4 1 6; 7 8 1]
b = Vector(3:5)
#連立一次方程式Ax=bの解xを求める
x = A \ b
```




    3-element Vector{Float64}:
     -0.07692307692307677
      0.6153846153846153
      0.6153846153846154




```julia
#逆行列を用いて計算しても解を求めることができる。
inv(A) * b
```




    3-element Vector{Float64}:
     -0.07692307692307704
      0.6153846153846154
      0.6153846153846154



## 11-3. 数学定数、三角関数、指数・対数関数
### 数学的定数
円周率は<br>
<b>pi</b><br>
もしくは<br>
<b>π</b>(\piと入力した後にTabキーを押す)<br>
と書くことで記述できます


```julia
#円周率
pi
```




    3.1415




```julia
#円周率
π
```




    π = 3.1415926535897...



自然対数は<br>
<b>ℯ</b> (\eulerと入力した後にTabキーを押す)<br>
と記述することで計算できます


```julia
#自然対数
ℯ
```




    ℯ = 2.7182818284590...



### 平方根・三乗根
平方根は<br>
<b>sqrt(平方根を計算したい数)</b><br>
三乗根は<br>
<b>cbrt(三乗根を計算したい数)</b><br>
と記述することで計算できます


```julia
#ルート2
sqrt(2)
```




    1.4142135623730951




```julia
#8の3乗根
cbrt(8)
```




    2.0



### 複素数
Juliaでは複素数の扱いがほかの言語と比べて比較的簡単に書けます。具体的には、<b>im</b>と書きます。<br>
また、<b>complex関数</b>を用いても記述することができ<br>
<b>complex(実数部分, 虚数部分)</b><br>
と記述します。


```julia
#1+2i
z = 1 + 2im
```




    1 + 2im




```julia
#1+3i
z = complex(1, 3)
```




    1 + 3im




```julia
z = complex(1, 3)
#実数部分のみを参照
real(z)
```




    1




```julia
z = complex(1, 3)
#虚数部分のみを参照
imag(z)
```




    3



### 共役複素数
共役な複素数を計算するためには<b>conj</b>を用いて、<br>
<b>conj(共役な複素数を求めたい複素数)</b><br>
と記述します。


```julia
z = complex(1, 3)
conj(z)
```




    1 - 3im




```julia
#複素数の絶対値を求める
abs(z)
```




    3.1622776601683795



### 符号確認
符号の確認には<b>sign</b>を用いて、<br>
<b>sign(符号を確認したい数値)</b><br>
と記述します。<br>
正の場合は1、負の場合は-1、0の場合は0を返します。


```julia
a = -3
sign(a)
```




    -1




```julia
b = 4
sign(b)
```




    1




```julia
c = 0
sign(c)
```




    0



### 三角関数


```julia
sin(π / 2)
```




    1.0




```julia
#複数の要素をsin関数に渡すこともできるが、その場合はドット演算子が必要
x = [pi/2, pi, 3/2*pi]
sin.(x)
```




    3-element Vector{Float64}:
      0.999999998926914
      9.265358966049026e-5
     -0.9999999903422263



### 対数計算
自然対数は<br>
<b>log(自然対数を計算したい数)</b><br>
常用対数は<br>
<b>log10(常用対数を計算したい数)</b><br>
と記述することで計算できます。


```julia
#自然対数の計算
log(2)
```




    0.6931471805599453




```julia
#常用対数の計算
log10(1000)
```




    3.0



### 指数計算
乗数計算の演算子には<b>^</b>を用います。


```julia
x = 5
x ^ 3
```




    125



### おまけ
オイラーの公式も、Juliaを使えば簡単に計算できます。<br>
$exp(imθ) = cosθ + im*sinθ$


```julia
exp(im * π)
```




    -1.0 + 1.2246467991473532e-16im



# 12. Appendix
## もっと学びたい人への推薦図書およびwebサイト
　特にお勧めしたいものには<b>(超推薦!)</b>、初学者でも苦痛なく読めそうだなというものには<b>(初心者向け)</b>、少し難しいなというものには<b>(上級者向け)</b>と付けています。すべて個人的な主観です。
### Julia
- [『Quantitative Economics with Julia』 (Jesse Perla、Thomas J. Sargent、John Stachurski)](https://julia.quantecon.org/)<br>
    <b>(超推薦!)</b> 英語ですが、気合のめちゃくちゃ気合の入った学習教材で、juliaだけでなく定量分析も学べます。そして無料です!<br>
- [『JuliaTokyo』 (佐藤建太、久本空海、村田賢太、有賀康顕、ほか)](http://julia.tokyo/)<br>
    珍しく日本語のJuliaの文献があります<br>
- [『PythonistaのためのJulia100問100答』 (佐藤建太)](http://bicycle1885.hatenablog.com/entry/2014/12/23/170745)<br>
    読み物として面白い<br>
- [『高速でJuliaを学ぶチュートリアル』 (佐藤建太)](https://github.com/bicycle1885/Julia-Tutorial)<br>
    日本語のチュートリアル<br>
- [『Econometrics lecture notes with examples using the Julia language』(Michael Creel)](https://github.com/mcreel/Econometrics)<br>
    バルセロナ自治大の講義資料。英語だけれども、Julia + 計量経済学の資料として参考になる。疑似ベイズ推定の話とかは渋くて面白い。<br>
- [『Performance Tips The Julia Language』](https://docs.julialang.org/en/v1/manual/performance-tips/)<br>
    Juliaは書き方のコツをつかまないと実は速くないが、そのためのコツが凝縮されてる必読ドキュメント<br>
- [『Julia for Numerical Computation in MIT Courses』 (Steven G. Johnson)](https://github.com/mitmath/julia-mit)<br>
    MITのSteven先生の数値計算の講義資料。数値計算のチュートリアルとしては最適ですぐに計算ができるようになる<br>
- [『Introduction to Numerical Methods』 (Steven G. Johnson)](https://github.com/mitmath/18335)<br>
    MITのSteven先生の講義資料。Juliaの入門コースで、Juliaと相性の良い数学が学べます<br>

### 統計基礎
- [『Rによるやさしい統計学』 (山田剛史、杉澤武俊、村井潤一郎)](https://amzn.to/32HPqol)<br>
    <b>(初心者向け)</b> 統計を全く知らない入門者用の教科書としてベストで、統計とRの使い方の両方を学べます。もともと文系学生用に作られたテキストなので数学が苦手な人にも読みやすいです。数式を減らして代わりに徹底してRでコードを書いて実践し、なおかつプロットなどの可視化で視覚的に体感できるようになっているのですごくわかりやすいです。サンプルサイズ設計についても書かれている入門者用の本はこの本くらいではないでしょうか。検定論には触れていないので、そこから先の話は中級者用の本で学びましょう。
- [『Rで学ぶ確率統計学 一変量統計編』 (神永正博、木下勉)](https://amzn.to/3n2276C)<br>
    <b>(超推薦!)</b> 中級者向けの教科書として最適。データサイエンティストを目指すのだとしたらジュニアでもこのくらいの統計は最低限押さえておきたい。たいてい数理統計の本は定理と証明ばかりになりがちだけれども、実践的なRでのシミュレーションも充実しています。問題に対する解答も丁寧
- [『Rで学ぶ確率統計学 多変量統計編』 (神永正博、木下勉)](https://amzn.to/3dyJKTP)<br>
    <b>(超推薦!)</b> 中級者向けの教科書として最適。データサイエンティストを目指すのだとしたらジュニアでもこのくらいの統計は最低限押さえておきたい。2×2分割表・線形モデル・GLM・PCA・ANOVAなど、実験データの分析で頻出のトピックがバランスよくまとめられています。尤度比検定に関しては統計の本で一番わかりやすいのではないのかとも思っています。たいてい数理統計の本は定理と証明ばかりになりがちだけれども、実践的なRでのシミュレーションも充実しています。問題に対する解答も丁寧。Rを実際のデータに対して実践するとどういう結果を返すのかを例示するのは今後の統計学の教科書のスタンダードになってほしいですね。
- [『新版 統計学のセンス』 (丹後俊郎)](https://amzn.to/3n4GfHU)<br>
    <b>(超推薦!)</b> 信頼区間について最も丁寧に解説している教科書だと思っています。適切な目で統計データを見るためのセンス、考え方、捉え方を養うことを目的に執筆された本で、基礎的な統計学の知識があればサクサク読めます。統計の理論よりも使い方に重点をを射ているのが好印象で、事例豊富でコラムのまとめがわかりやすく、実験計画などの統計学をどう運用するかの話も載っているのもよいですね。実は、統計的因果推論と非劣性検定にもちゃんと触れているのはこの本以外であまり見かけないです。
- [『コア・テキスト統計学』 (大屋幸輔)](https://amzn.to/3txewBP)<br>
    数式説明も初歩から丁寧なので数学は苦手だけど統計を学びたい人におすすめ。因果推論の基礎的な考え方も紹介されています。分かりやすいだけでなく、結構厳密な話もしています。
- [『統計学』 (久保川達也、国友直人)](https://amzn.to/3tKo2Sx)<br>
    入門書としては少し堅めだけれども、しっかり学びたい人には武器になります。社会・経済データとして標本調査や時系列分析の話題にも触れているのも推しポイント。
- [『現代数理統計学の基礎』 (久保川達也)](https://amzn.to/3ege1pt)<br>
    分布論、統計的推測決定理論、線形モデルなどのトピックを数学的に解説しています。理論中心であり、数学が苦手な人にはしんどいが、数理統計に興味があるのであれば読んでみてもよいかも。初学者にはややボリューミーなので2冊目以降の本としておすすめ。ガチ勢はなぜかみんな読んでる。
- [『現代数理統計学』 (竹村彰通)](https://amzn.to/3szom4Z)<br>
    伝統的な名著ですが、結構お堅い。他の本だと常識だからとさらっと流されていることでも、簡潔に証明がついていたりするのがありがたい。シリアスに数理統計を勉強したいガチ勢はみんな読んでる。
- [『Rによる統計的学習入門』 (G. James、D. Witten、T. Hastie、R. Tibshirani)](https://amzn.to/3tzhExh)<br>
    古典的な名著の邦訳版で、理数系をバックグラウンドとしない学部生向けに書かれた王道の良書。しかし、安易な気持ちで読むと難しくて爆死する可能性はある。タイトルに統計的学習入門と入っているのでここにカテゴライズしたけれども、機械学習に入れるべきだったかもしれない。基本的なアルゴリズムの概要、動き方、目的、特徴などを理解するのにおすすめ。Rで実践的に学習できるのは良いですね。英語に自信がある人は、英語版のPDFが無料で公開されています。

### ベイズ統計学・計算機統計学
　最近はどこもかしこもベイズベイズベイズと叫ばれる時代ですので、ベイズ統計に強くなっておけば現代においてはドヤ顔できると思います。現在の統計学のブームです。
- [『RとStanではじめる ベイズ統計モデリングによるデータ分析入門』(馬場真哉)](https://amzn.to/3tHAjH9)<br>
    <b>(超推薦!)</b> ベイズ統計や統計モデリングの入門書として最もお勧めしたいのが本書で、GLM, GLMM, 階層ベイズ、状態空間モデルなど、伝統的な手法からモダンなモデリング手法までをめちゃめちゃわかりやすく、かつ実践的に学ぶことができます。個人的に、「本書では何を扱わないか」が明記されている教科書は良書であることが多いと感じています。
- [『モンテカルロ統計計算』 (鎌谷研吾)](https://amzn.to/3duVG8U)<br>
    stanで適当にベイズ統計をやるのではなく、0からRでベイズの実装をめちゃくちゃわかりやすく解説してくれているので、ベイズ統計やMCMCの裏側について詳しくわかります。ただし実践的な内容はなく、あくまでも理論を学ぶための本です。
- [『Bayesian Data Analysis』(Andrew Gelman、John B. Carlin)](https://amzn.to/32zYwTW)<br>
    Stanの作成者であるGelman大先生の鈍器、通称BDA。ベイズ統計学と必要な計算機統計学の手法を一通り学べる良い教科書。最近はどこもかしこもベイズベイズという大ベイズ時代なので、持っていて辞書的に使うだけでも非常に役に立つかも。
- [『Nonlinear Time Series: Theory, Methods and Applications with R Examples』(Randal Douc、Eric Moulines)](https://amzn.to/3tEjKvO)<br>
    <b>(上級者向け)</b> 数学が結構難しい。正直読むのに骨が折れますが、なんか状態空間モデルにめちゃめちゃ詳しくなれたような気がする本。"wirh R"とタイトルに関していますが、Rはオマケ程度です。
- [『The Bayesian Choice: From Decision-Theoretic Foundations to Computational Implementation』 (Christian Robert)](https://amzn.to/3dCtxwH)<br>
    <b>(上級者向け)</b> ベイズ統計学がなぜ正しいのかの数学的な妥当性を解説している本で、「ああなるほど、確かにベイズ統計ってすごいんだな」と納得させられる本。実践向きではないですけど、こういう読書もたまには良いですね。
- [『Monte Carlo Statistical Methods』(Christian Robert、George Casella)](https://amzn.to/3n8571k)<br>
    <b>(上級者向け)</b> 様々なモンテカルロ法が紹介されているので、モンテカルロ法について知りたい人は是非読んでみるとよいでしょう。
- [『Computer Age Statistical Inference: Algorithms, Evidence, and Data Science』(Bradley Efron、Trevor Hastie)](https://amzn.to/3sBvihZ)<br>
    <b>(上級者向け)</b> 尤度解析やSVM、ランダム・フォレスト、ニューラル・ネットワーク等の広範囲な分野について薄く広く語られています。電子版でよければStanford大学のHPから無料でダウンロードできます。
- [『An Introduction to Sequential Monte Carlo』(Nicolas Chopin、Omiros Papaspiliopoulos)](https://amzn.to/3tDGegz)<br>
    逐次モンテカルロ法について初学者でも学べる珍しい教科書。いろんな範囲の逐次モンテカルロ法を紹介しているので読んでいて面白いです。
- [『Bayesian Filtering and Smoothing』(Simo Sarkka)](https://amzn.to/3sDDizd)<br>
    フィルタリングやスムージングについて易しく解説してある良書です。カルマン・フィルターとかの解説もあります。

### 時系列分析
- [『経済・ファイナンスデータの計量時系列分析』(沖本竜義)](https://amzn.to/32wLir5)<br>
    「時系列分析といえばこの本」と言われる名著で、時系列分析関連の理論についてはこれ1冊である程度カバーできます。本格的な時系列モデリングの入門書として最適。
- [『基礎からわかる時系列分析 ―Rで実践するカルマンフィルタ・MCMC・粒子フィルター』(萩原淳一郎、瓜生真也、牧山幸史)](https://amzn.to/2P7xgZJ)<br>
    結構広範なベイジアン時系列モデリングをRコード付きで解説してあるのでベイズ統計を駆使した時系列分析を学びたい方にはお勧めです。粒子フィルタとかの話まで踏み込んでいて読み応えがあります。
- [『Time Series Analysis』(James D. Hamilton)](https://amzn.to/3vd7L8V)<br>
    未読！ しかしその筋の人からすると名著らしい。鈍器です。

### 計量経済学
- [『効果検証入門〜正しい比較のための因果推論/計量経済学の基礎』(安井翔太)](https://amzn.to/3mZGe81)<br>
    <b>(超推薦!)</b> マーケティングや実験、分析に関わる全ての人にお薦めの統計的因果推論の入門書。段階を踏みながら計量経済学的な理論面での背景も丁寧に解説しつつ、Rコードによる実践例も付して分かりやすい。因果推論は実は難しい統計学や機械学習を使わなくても「実験のやり方を工夫するだけ」でもかなりのことが出来るので、マーケティング、企画は、営業など非エンジニア人にも是非読んで欲しい。具体的には、統計的因果推論の枠組みを理解し、実験計画を立案し、顧客に提案して実行し、そこから得られた結果に基づいて新たなマーケティング方針の提案を行えるようになれます。とにかく因果推論の理論と実装までいかなくても 効果測定のバイアスの話は職種問わず知っておいた方が良いです。
- [『計量経済学』(浅野皙、中村二朗)](https://amzn.to/3dBtrWp)<br>
    計量経済学の入門書は行列を書かないことが多いのですが、この本は行列を使った説明がしっかり、かつ平易に解説がなされています。．
- [『計量経済学(西山慶彦、新谷元嗣、川口大司、奥井亮)](https://amzn.to/3sxDvUz)<br>
    計量経済学における幅広いトピックを扱っていて、その実証例もたくさん載っています。
- [『Advanced Quantitative Economics with Python](https://python-advanced.quantecon.org/)<br>
    先に挙げたJuliaで計量経済を学べるサイトのPython版です

### 機械学習
　機械学習を学ぶ際に重要なのは本を「眺める」ことではなく、「完全に理解しきる」ことです。数式まで含めて100%詳細まで何を聞かれても答えられるようになることを目標に本を読んでみてください。機械学習は「眺める」のが特に意味をなさない分野になりつつあります。
- [『Machine Learning』 (Andrew Ng)](https://www.coursera.org/learn/machine-learning)<br>
    <b>(超推薦!)</b> <b>(初心者向け)</b> StanfordのAndrew大先生の講義で、英語である点を除けば機械学習の入門用教材としてダントツでおすすめ。とりあえず迷ったらAndrew先生の講義を見てください。これが機械学習の基礎のすべてです。一応日本語字幕もあります。なんといっても無料!!
- [『Stanford CS229: Machine Learning | Autumn 2018』 (Andrew Ng)](https://www.youtube.com/playlist?list=PLoROMvodv4rMiGQp3WXShtMGgzqpfVfbU)<br>
    <b>(超推薦!)</b> StanfordのAndrew大先生の講義で、これもダントツでおすすめできる講義だけれども機械学習についての基礎的な知識は持ち合わせている人向け。StanfordのHPで講義資料も公開されており、この資料もまた非常に質が高いです。これも無料!!
- [『機械学習のエッセンス』 (加藤公一)](https://amzn.to/3dysca4)<br>
    <b>(超推薦!)</b> <b>(初心者向け)</b> 機械学習をsk-learnなどのパッケージを使用することなくーから書いていくことで、その理論を理解できる最強の入門書です。実は、機械学習について話しているのは最終章くらいで残りはPythonの基本的な文法や基礎的な数学の話だったりするので、Pythonや数学の知識が一切ない人でも読めます。こう書くとただの初心者用の本に見えるかもしれませんが、ガチ勢が読んでも得られる知識は大きいと思います。ただしあくまでの機械学習の理論を理解するための本であり、実装やハイパーパラメーターチューニングには触れていません。
-[ 『はじめてのパターン認識』 (平井有三)](https://amzn.to/3sZFoJD)<br>
    「はじパタ」という略称でおなじみの名著で、機械学習に関する広汎なテーマをバランスよく扱っているにもかかわらず、コンパクトにまとまっていて非常に読みやすいので独学に最適。Rによる実践例が紹介されているのも魅力的。ベイズの識別規則や性能評価といった基礎事項から、線形分類器、カーネル法、行列分解、クラスタリング、アンサンブル学習機と主要なトピックを簡潔かつ分かりやすくまとめられており、機械学習の全体像を眺めるのにベストの一冊です。
- [『統計的学習の基礎 ―データマイニング・推論・予測―』 (Trevor Hastie,Robert Tibshirani,Jerome Friedman)](https://amzn.to/32ZNvvd)<br>
    「カステラ本」の略称で名高い一冊で、名著PRMLがベイズベイズし過ぎている一方で、この1冊に統計的機械学習のほぼ全てが詰まっています。単に数式を追うだけでなく、大抵の機械学習手法について擬似コードが添えられており、実装についてもイメージをつかみやすいのが素晴らしい。Deep Learning以降の流れをカバーしていないのでDeep全盛の現在では物足りないと思う人も多いかもしれませんが、それ以外のほぼ全ての機械学習分野の話題がカバーされているので辞書として使う上では今でも最適の鈍器です。実はGDBT系のモデルのアルゴリズムとその解説をきちんと載せている数少ない書籍の一つです。英語版PDFならweb上で無料で読めます。
- [『仕事ではじめる機械学習 第2版』 (有賀康顕、中山心太、西林孝)](https://amzn.to/3u5KG7L)<br>
    タイトル通り理論よりも実践に力を入れた解説書で、実際のビジネスの現場でよく用いられるシステム構成と、個々のビジネス要件を踏まえた上でどのような機械学習システムを構築すべきか、そしてそれをいかにして構築するか、学習データの収集とその方法、実データに対する機械学習（もしくは機械学習を使わないで済ませる）の適用事例や、構築された機械学習システムの評価方法など、まさに「仕事で実際に」機械学習を用いる上では必須の項目が網羅されています。
- [『パターン認識と機械学習 上/下』 (C.M. ビショップ)](https://amzn.to/2QMeS9w)<br>
    <b>(上級者向け)</b> PRMLという略称で知られる難解なことで有名な本です。さすがに古いのですが、最近ベイズが大人気なのでベイズ機械学習が包括的に学べるということで一応載せておきます。ちなみに、系列データ分析に関してはこれだけ古い本でも一番うまく説明されていると思っています。一方、ベイズ慣れしていない読者にとっては結構読みにくいのと、実装に関してのサポートは弱いです。
-[ 『Kaggleで勝つデータ分析の技術』 (門脇大輔、阪田隆司、保坂桂佑、平松雄司)](https://amzn.to/3u88Oqj)<br>
    タイトルがいかにもコンペ対策書みたいですが、実際にはKaggleだけでなく評価指標の置き方、特徴量の扱い方、モデル評価と交差検証の方法、モデルのチューニング、モデルの組み合わせ方、leakageのような落とし穴、など、あらゆる機械学習の実践の場で問題となる事項が網羅されています。また、"ML design"の考え方が全て載っており、実務家としては読んでおきたい一冊です。
- [『Machine Learning: a Probabilistic Perspective』(Kevin Murphy)](https://amzn.to/3tEiZ5X)<br>
    <b>(超推薦!) (上級者向け)</b> MLaPPと略される伝統的な名著ですが、鈍器としても使える分厚さなので通読するというより、リファレンスとして使うのが適当かもしれません。ある程度の教養数学(微積分、線形代数)とプログラミングに関しては既知という前提で書かれていますがしっかりまとめられているので、膨大な範囲を持つ機械学習分野の大局観を得られます。今までの人生で一番脳に負担がかかったのはこの本を読了することでした。

### 深層学習
　深層学習は機械学習を理解していれば"簡単"なので、まずは機械学習を徹底して理解することを最優先したいです。個人的に深層学習には機械学習並みの面白さを感じないので、深層学習ガチ勢に推薦書を聞いてみたほうが良いかもしれません。
- [『Deep Learning Specialization』(Andrew Ng)](https://www.coursera.org/specializations/deep-learning)<br>
    「エラー分析をやれ」、「ラベルが間違ったデータを綺麗にしろ」、「最初のモデルは素早く作り、そしてイテレーションを重ねろ」など、深層学習以前に重要なことまでしっかりと教えてくれる。知らないことはすべてAndrew Ngが教えてくれる。
- [『深層学習』 (岡谷貴之)](https://amzn.to/2QwZDRU)<br>
    DNN、CNN、RNNなど一通りのDeep Learningの基礎がコンパクトにまとめられています。深層学習の本の中では数学をあまり取り扱わないタイプなので数学が苦手な人にとっても読みやすいかと思います。最新のネットワークについてはもっと新しい本で補完しましょう。
- [『scikit-learn、Keras、TensorFlowによる実践機械学習 第2版』 (Aurélien Géron)](https://amzn.to/3gJMPSP)<br>
    一般的な機械学習の適用事例から、TensorFlowで取り組むべきDeep Learningの適用事例まで、それらの理論的・アルゴリズム的解説も織り交ぜながら実際のコードと実行例を付して解説していて(TensorFlowによる強化学習の実装例や、事前学習や異常検出などに使われるautoencoderの実装例なども載っています)分かりやすい本です(なんとすべての実行例がGitHub上で公開されています!)。TF / Kerasの本としても非常に良い解説書で、著名なCNN / RNNモデルの生ネットワークの書き方なんかも紹介されていて便利です。Attention, Transformer, GANや強化学習など最近の話題もカバーしています。網羅性が高く、初学者から玄人まで読む価値が高い本だと思います(ただし、Pyhtonの文法理解が微妙な人は途中で躓くかもしれない)。ちなみに、タイトルに"scikit-learn"と入っていますが、sk-learn自体の解説は物足りないような気がします。
- [『深層学習』 (Ian Goodfellow、Yoshua Bengio、Aaron Courville)](https://amzn.to/3nof0I8)<br>
    まあ紹介しないわけにはいかないでしょうGoodfellow本です。さすがに古い本なのでこれ一冊で全てを理解、という訳にはいきませんが、Deep Learningの基礎を学ぶ本としてはまだまだ現役だと思います。第1部の数学についての解説は既に機械学習の基礎を分かっている人であれば読み飛ばしても問題ないかと思います。英語版は全文無料で公開されているので、英語でも大丈夫な人はwebで読みましょう。
-[ 『図解速習DEEP LEARNING』 (増田知彰)](https://amzn.to/32Oa3z5)<br>
    現代のDeep諸系統全盛期における代表的なネットワークの大半の組み方とその実践、webへのデプロイまでもをこれ一冊でカバーするという、極めて実践的な本です。一冊に一般的な表形式・画像・系列（自然言語テキスト含む）データに対するNNに加えて、映像・音声データやGANや強化学習ももカバーしていて、さらにその全てに簡潔なアルゴリズムの説明とColaboratory + TensorFlow + Kerasによる実践例が付されており、かなり内容盛沢山な本です。色んな分野での手法が簡単に分かる単なるレシピ集ではなく、学ぶ動機付けや情報収集の仕方、実務での適用方法についてのガイドがあり、「知る」で止まらず「活用する」まできっちりナビしてくれています。

### 自然言語処理
　"ことば"という概念にめちゃくちゃ興味があるので、実は自然言語処理はかなり好きな分野です。この分野はMcKinsey入社後に結構本格的に勉強してきたのですが、とにかく言えることは「『Speech and Language Processing』を読め!」につきます。巷で言われてる"自然言語処理"はそのほとんどが形態素解析のことだと思ってもよいでしょう。言語処理分野においては言語生成(機械翻訳含む)はやや難しいので、初心者は他分野から学んだほうが良いかと思います。
- [『Speech and Language Processing』 (Dan Jurafsky、James H. Martin)](https://amzn.to/3x6EzlJ)<br>
    <b>(超推薦!)</b> 自然言語処理を学ぶのであれば文句なしにダントツで一番おすすめの本(英語だけど……)。NLPガチ勢の中にはこの本を読まずに自然言語処理をやっているとモグリと思う人もいれば「お前は教科書を読むと死ぬ呪いにかかってるのか?」と思う人もいる。この世にある自然言語処理の教科書はあらかた読んだという化け物のような友人は、これが一番良かったといっていました。以下に挙げる本は本来ならば『Speech and Language processing』読んでほしいけどいきなり分厚い英語の専門書はちょっとな……という人向けの位置づけです。第三版が今後刊行される予定ですが、未完成のドラフトはweb上で無料公開されています。
- [『言語処理のための機械学習入門』 (高村大也、奥村学)](https://amzn.to/3swF98W)<br>
    名著として名高い一冊。そもそも言語処理に興味がなくても機械学習の話だけで面白い。特に、アルゴリズムを数学的に解説するだけでなく、一つ一つ式の展開を追っていくことでどのようにアルゴリズムが期待される結果を出していくかを逐一明示してあるところが面白いです。実はラグランジュの未定乗数法とディリクレ分布の数式の意味はこの本で初めて理解できました。もちろん自然言語処理の入門としても有用な一冊だと思います。なにげにデータを用いた実験の手順を適切に説明しているパートもあったりします。
- [『自然言語処理〔改訂版〕』 (黒橋禎夫)](https://amzn.to/3mZwTNz)<br>
    <b>(初心者向け) </b>放送大学のテキストで、かなりわかりやすい。機械学習や深層学習にはあまり触れておらず、コードとかの掲載はありませんが、言語学の視点から自然言語処理について解説されています。日本語で自然言語処理の入門書を読みたいのであればとりあえずこの本がまず一番に挙がります。
- [『NLPプログラミングチュートリアル』 (Graham Neubig)](http://www.phontron.com/teaching.php?lang=ja)<br>
    NAISTのグラム先生のチュートリアル資料で、わかりやすいけど結構本質的なこところまで扱っています。無料。
- [『言語処理100本ノック 2020 (Rev 2) - NLP100 2020』(岡崎直観)](https://nlp100.github.io/ja/)<br>
    言わずと知れた岡崎先生の100本ノック。とにかく実践あるのみ！ コードを書こう！！
- [『機械翻訳』 (渡辺太郎、今村賢治、賀沢秀人、Graham Neubig、中澤敏明、奥村学)](https://amzn.to/32sKYth)<br>
    日本語の本ですが機械翻訳については"世界一"詳しい名著だと思っています。自然言語処理においても機械翻訳(と言語生成)は難所中の難所ですが、翻訳技術に興味があるのであればまずお勧めしたい本です。
- [『Introduction to Natural Language Processing』 (Jacob Eisenstein)](https://amzn.to/3sxEggi)<br>
    いろんなところでおすすめされているので興味があれば読んでみてもよいと思いますが、個人的にはこれを読む時間があるのであれば『Speech and Language Processing』をまず読むべきだと思っています。<br>
- [『Embeddings in Natural Language Processing』 (Mohammad Taher Pilehvar, Jose Camacho-Collados)](https://amzn.to/2QE4ArA)<br>
    いろんなところでおすすめされているので興味があれば読んでみてもよいと思いますが、個人的にはこれを読む時間があるのであれば『Speech and Language Processing』をまず読むべきだと思っています。


### 数学
- [『測度と積分―入門から確率論へ』(Marek Capinski、Ekkehard Kopp)](https://amzn.to/32Brm6d)<br>
    <b>(上級者向け) </b>測度論的確率論がめちゃくちゃわかりやすく解説されています。日本語版は絶版なので結構なお金を出さないと手に入らないのが欠点
- [『Stochastic Processes and Applications: Diffusion Processes, the Fokker-Planck and Langevin Equations』(Grigorios A. Pavliotis)](https://amzn.to/2QNeNlB)<br>
    <b>(上級者向け) </b>確率過程についての教科書です。割と物理の人にとっては読みやすいのかなと思いますが、僕は物理の知識は皆無なので気合入れて読みました。確率微分方程式とかをガッツリ学びたかったら気合入れて読みましょう。

### 強化学習
強化学習については私はあまり強くないので、強化学習ガチ勢の友人から紹介してもらった本を掲載しておきます。私自身も途中読みのものが多いです……(強化学習は先述した[『図解速習DEEP LEARNING』](https://amzn.to/3ueuX6n)や[『scikit-learn、Keras、TensorFlowによる実践機械学習 第2版』](https://amzn.to/3vFNBVl)でもカバーされています)。
- [『これからの強化学習』(牧野貴樹、澁谷長史、白川真一、ほか)](https://amzn.to/338JgxC)<br>
    基礎からすごく丁寧に強化学習を解説してくれています。第一章だけでも読む価値はあり、二章は時間がなければ飛ばしてもよいかもしれません。
- [『Reinforcement Learning, second edition: An Introduction』(Richard S. Sutton、Andrew G. Barto)](https://amzn.to/3u8fg0C)<br>
    原点にして頂点らしい。まだ読み途中。初版は邦訳されているけど第二版は未訳なので早く訳されてほしい……。英語に苦戦するというよりも著者の独特な言い回しに苦戦してます……
- [『Pythonで学ぶ強化学習 [改訂第2版] 』(久保隆宏)](https://amzn.to/2RjQ7Sg)<br>
    コード例が大量に乗っているので理論だけ語るのではなく実践面まできっちりとサポートされているのが嬉しいです。何気に結構最新の深層強化学習の話までカバーされていたりします。
- [『速習 強化学習』(Csaba Szepesvari)](https://amzn.to/2Rgo46f)<br>
    <b>(上級者向け)</b> 何の気なしに友人からおすすめされたけれど、最初の3ページを読破するのに22時間かかった。果たして"速習"とは。強化学習だけでなく精神も鍛えられると思います。これを読むと強化学習を完全に理解できるといわれたけれど、そもそもこれを読める人は既に強化学習を完全に理解できていると言う説もある。
- [『強化学習』(森村哲郎)](https://amzn.to/3vsONv4)<br>
    <b>(上級者向け)</b> ちゃんと数式を追って強化学習を理解するための本です。いきなり挑戦するのはしんどいので、基礎的な本でいったん強化学習の全体像を理解してから挑戦してみるとよいと思います。

### その他アルゴリズム・計算機科学など
情報科学関係を学びたいのであれば読んでおいて損はない名著を並べておきます。実はこの辺はそこまで詳しいわけではないので、各書についてのコメントは省略します。
- [『決定版 コンピュータサイエンス図鑑』(Helen Caldwell, Claire Quigley, Patricia Foster)](https://amzn.to/3syn4Hj)<br>
- [『最短経路の本 レナのふしぎな数学の旅』 (Peter Gritzmann, Rene Brandenberg)](https://amzn.to/2QjDczv)<br>
- [『CPUの創りかた』(渡波郁)](https://amzn.to/3dE7ndw)<br>
- [『32ビットコンピュータをやさしく語る はじめて読む486』(蒲地輝尚)](https://amzn.to/3dHhb6N)<br>
- [『マスタリング TCP/IP 入門編』(井上直也、村山公保、竹下隆史、荒井透、苅田幸雄)](https://amzn.to/3sCqrgs)<br>
- [『岩波講座 ソフトウェア科学 オペレーティングシステム』(前川守)](https://amzn.to/3tHq9Gv)<br>
- [『オペレーティングシステム―設計と理論およびMINIXによる実装』(Andrew S. Tanenbaum、Albert S. Woodhull)](https://amzn.to/3dCm9S3)<br>
- [『プロセッサを支える技術』(Hisa Ando)](https://amzn.to/3n68qWN)<br>
- [『Webを支える技術』(山本陽平)](https://amzn.to/3sDc5fU)<br>
- [『ふつうのコンパイラをつくろう』(青木峰郎)](https://amzn.to/3sCrbCg)<br>
- [『最新コンパイラ構成技法』(Andrew W. Appel)](https://amzn.to/2RR2XHU)<br>
- [『30日でできる! OS自作入門』(川合秀実)](https://amzn.to/3tQfY2F)<br>
- [『プログラミングコンテストチャレンジブック』(秋葉拓哉、岩田陽一、北川宜稔)](https://amzn.to/3xccvgB)<br>
- [『関数プログラミング入門 ―Haskellで学ぶ原理と技法―』(Richard Bird)](https://amzn.to/3dEOyHk)<br>
- [『C++ Templates: The Complete Guide』(David Vandevoorde、Nicolai M. Josuttis、Douglas Gregor)](https://amzn.to/3gpRHfF)<br>
- [『純粋関数型データ構造』(Chris Okasaki)](https://amzn.to/2QGn6zK)<br>
- [『エキスパートCプログラミング―知られざるCの深層』(Peter van der Linden)](https://amzn.to/3v8PLMN)<br>
- [『Modern C++ Design―ジェネリック・プログラミングおよびデザイン・パターンを利用するための究極のテンプレート活用術』(Andrei Alexandrescu)](https://amzn.to/3xbYX4Q)<br>
- [『Effective C++ 第3版』(Scott Meyers)](https://amzn.to/3gs1Ng1)<br>
- [『Exceptional C++―47のクイズ形式によるプログラム問題と解法』(Harb Sutter)](https://amzn.to/3sDtaqb)<br>
- [『入門 コンピュータ科学　ITを支える技術と理論の基礎知識』(J.Glenn Brookshear)](https://amzn.to/3sDt4Pl)
